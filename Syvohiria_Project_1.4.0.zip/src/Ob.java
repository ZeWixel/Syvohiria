public class Ob { int t,x,y,a,b,c,d,e,w; String s; }
