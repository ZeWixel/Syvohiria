import javax.microedition.lcdui.*;
import java.util.Random;

/** PNG-backed art resources for MIDP 2.0 / CLDC 1.1. */
public class Gfx {
  static final int TW=32, TH=16, WH=32;
  static Image[] floor=new Image[4];
  static Image[] prop=new Image[128];
  static Image wallCut, pit;
  static Image[][] pl=new Image[3][4], idle=new Image[3][3];
  static Image[] hol=new Image[4], hnd=new Image[4], fly=new Image[4], boss=new Image[4];
  static Image[] pipeHold=new Image[3], pistolHold=new Image[3];
  static Image[][] pipeSwing=new Image[3][4], punch=new Image[3][4], pistolFire=new Image[3][2];
  static Image nina, carDay, carRust, busDay, busRust, car, bus;
  static Image tree, lamp, bell, kiosk, phonebooth, console, speaker, controlPanel;
  static Image bookshelf, counter, pew, altar, vending;
  static Image[] itemIcon=new Image[13];
  static Image titleCity;
  static int bg;
  static Random r=new Random();

  static int cl(int v){ return v<0?0:(v>255?255:v); }
  static int sh(int c,int d){
    return (cl(((c>>16)&255)+d)<<16)|(cl(((c>>8)&255)+d)<<8)|cl((c&255)+d);
  }
  static int mix(int a,int b,int t){
    int ra=(a>>16)&255, ga=(a>>8)&255, ba=a&255;
    int rb=(b>>16)&255, gb=(b>>8)&255, bb=b&255;
    return (cl(ra+(((rb-ra)*t)>>8))<<16)|(cl(ga+(((gb-ga)*t)>>8))<<8)|(cl(ba+(((bb-ba)*t)>>8)));
  }

  static Image art(String n){
    try{ return Image.createImage("/art/"+n); }catch(Exception e){ return null; }
  }
  static Image blank(int w,int h){ return Image.createRGBImage(new int[w*h],w,h,true); }
  static Image fallback(Image im,int w,int h){ return im==null?blank(w,h):im; }

  static void sprites(){
    String[] view={"d","u","s"};
    for(int d=0;d<3;d++){
      for(int i=0;i<4;i++){
        pl[d][i]=fallback(art("hero_"+view[d]+i+".png"),32,32);
        pipeSwing[d][i]=art("pipe_swing_"+view[d]+i+".png");
        punch[d][i]=art("punch_"+view[d]+i+".png");
      }
      for(int i=0;i<3;i++) idle[d][i]=art("idle_"+view[d]+i+".png");
      pipeHold[d]=art("pipe_hold_"+view[d]+".png");
      pistolHold[d]=art("pistol_"+view[d]+".png");
      for(int i=0;i<2;i++) pistolFire[d][i]=art("pistol_"+view[d]+"_fire"+(i+1)+".png");
    }
    for(int i=0;i<4;i++){
      hol[i]=fallback(art("hollow"+i+".png"),24,32);
      hnd[i]=fallback(art("hound"+i+".png"),32,20);
      fly[i]=fallback(art("flyer"+i+".png"),32,32);
      boss[i]=fallback(art("boss"+i+".png"),34,42);
    }
    nina=art("nina.png"); tree=art("tree.png"); lamp=art("lamp.png"); bell=art("bell.png");
    kiosk=art("kiosk.png"); phonebooth=art("phonebooth.png"); console=art("console.png");
    speaker=art("speaker.png"); controlPanel=art("control_panel.png");
    bookshelf=art("bookshelf.png"); counter=art("counter.png"); pew=art("pew.png");
    altar=art("altar.png"); vending=art("vending.png");
    titleCity=art("title_city.png");
    for(int i=0;i<itemIcon.length;i++) itemIcon[i]=art("icons/item"+i+".png");
    carDay=art("car.png"); carRust=art("car_rust.png");
    busDay=art("bus.png"); busRust=art("bus_rust.png");
  }

  /** Load the editable floor/block PNGs for the active map theme. */
  static void theme(int th){
    if(th<0||th>4) th=0;
    car=th>=3?carRust:carDay; bus=th>=3?busRust:busDay;
    switch(th){
      case 1: bg=0; break;
      case 2: bg=0; break;
      case 3: bg=0x0a0504; break;
      case 4: bg=0x050303; break;
      default: bg=0xb0b3b5;
    }
    String root="tiles/theme"+th+"/";
    floor[0]=fallback(art(root+"floor0.png"),TW,TH);
    floor[1]=fallback(art(root+"floor1.png"),TW,TH);
    floor[2]=fallback(art(root+"floor2.png"),TW,TH);
    floor[3]=fallback(art(root+"floor3.png"),TW,TH);
    pit=fallback(art(root+"pit.png"),TW,TH);
    wallCut=fallback(art(root+"wall_cut.png"),TW,TH+18);
    for(int i=0;i<prop.length;i++) prop[i]=null;
    prop['#']=art(root+"wall.png");
    prop['D']=art(root+"door.png");
    prop['E']=art(root+"security_door.png");
    prop['F']=art(root+"low_barrier.png");
    prop['G']=art(root+"gate.png");
    prop['Y']=art(root+"rust_block.png");
    prop['C']=art(root+"car_tile.png");
    prop['B']=art(root+"bus_tile.png");
    prop['K']=art(root+"shrub_block.png");
    prop['P']=art(root+"blue_block.png");
    prop['b']=art(root+"small_block.png");
    prop['=']=art(root+"counter_block.png");
    prop['S']=art(root+"shelf_block.png");
    prop['V']=art(root+"vending_block.png");
    prop['p']=art(root+"pew_block.png");
    prop['A']=art(root+"altar_block.png");
    prop['M']=art(root+"console_block.png");
    prop['O']=art(root+"speaker_block.png");
    prop['Q']=art(root+"control_panel_block.png");
  }

  // Smooth fog / darkness overlay is a display effect, not a baked world sprite.
  static Image ov; static int qw,qh;
  static void overlay(int W,int H,int col,int r1,int r2,int maxA,boolean fast,int seed){
    ov=null;
    qw=W/2+30; qh=H/2+30;
    int[] p=new int[qw*qh]; r.setSeed(seed);
    int[] bay={0,8,2,10,12,4,14,6,3,11,1,9,15,7,13,5};
    col&=0xFFFFFF;
    for(int j=0;j<qh;j++){
      int dy=qh-j;
      for(int i=0;i<qw;i++){
        int dx=qw-i;
        double d=Math.sqrt(dx*dx+dy*dy*2.25);
        int a;
        if(d<=r1) a=0; else if(d>=r2) a=maxA;
        else { double tt=(d-r1)/(r2-r1); a=(int)(maxA*tt*tt*(3-2*tt)); }
        if(a>0&&a<maxA){ a+=r.nextInt(15)-7; if(a<0)a=0; if(a>maxA)a=maxA; }
        if(fast) a=((a>>4)>bay[(i&3)+((j&3)<<2)])?255:0;
        p[j*qw+i]=(a<<24)|col;
      }
    }
    ov=Image.createRGBImage(p,qw,qh,true);
  }
}
