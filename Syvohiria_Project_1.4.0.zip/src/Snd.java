import javax.microedition.media.*;
import javax.microedition.media.control.*;
import java.io.*;
import java.util.Random;

/** Звук: шипіння радіо (генерований WAV), сирена, тони через Manager.playTone. */
public class Snd {
  static Player stat, siren;
  static VolumeControl sv;
  static boolean on=true, playing;
  static int curVol=-1;

  static byte[] wav(byte[] pcm){
    int n=pcm.length; byte[] b=new byte[44+n];
    put(b,0,"RIFF"); le(b,4,36+n,4); put(b,8,"WAVE"); put(b,12,"fmt "); le(b,16,16,4);
    le(b,20,1,2); le(b,22,1,2); le(b,24,8000,4); le(b,28,8000,4); le(b,32,1,2); le(b,34,8,2);
    put(b,36,"data"); le(b,40,n,4);
    System.arraycopy(pcm,0,b,44,n);
    return b;
  }
  static void put(byte[] b,int o,String s){ for(int i=0;i<4;i++) b[o+i]=(byte)s.charAt(i); }
  static void le(byte[] b,int o,int v,int n){ for(int i=0;i<n;i++) b[o+i]=(byte)((v>>(8*i))&255); }

  static byte[] noise(){
    Random r=new Random(5); int n=4800; byte[] p=new byte[n]; int lp=0;
    for(int i=0;i<n;i++){
      int v=r.nextInt(256)-128;
      lp=(lp*3+v)/4;
      int amp=((i/400)%3==0)?110:70;
      if(r.nextInt(300)==0) amp=127;
      int s=128+lp*amp/128;
      p[i]=(byte)(s<0?0:(s>255?255:s));
    }
    return wav(p);
  }
  static byte[] sirenWav(){
    int n=8000*4; byte[] p=new byte[n]; double ph=0;
    for(int i=0;i<n;i++){
      double t=i/8000.0;
      double tri=(t%2.0); tri=tri<1?tri:2-tri;
      double f=280+380*tri;
      ph+=2*Math.PI*f/8000.0;
      double s=Math.sin(ph)*0.7+Math.sin(ph*2)*0.2;
      double env=i<2000?i/2000.0:(i>n-4000?(n-i)/4000.0:1.0);
      int v=128+(int)(s*100*env);
      p[i]=(byte)(v<0?0:(v>255?255:v));
    }
    return wav(p);
  }

  static void init(){
    new Thread(){ public void run(){
      try{
        stat=Manager.createPlayer(new ByteArrayInputStream(noise()),"audio/x-wav");
        stat.realize(); stat.prefetch(); stat.setLoopCount(-1);
        sv=(VolumeControl)stat.getControl("VolumeControl");
      }catch(Throwable t){ stat=null; }
      try{
        siren=Manager.createPlayer(new ByteArrayInputStream(sirenWav()),"audio/x-wav");
        siren.realize(); siren.prefetch();
      }catch(Throwable t){ siren=null; }
    }}.start();
  }

  static void radio(int lv){
    if(!on) lv=0;
    if(stat==null) return;
    try{
      if(lv<=0){ if(playing){ stat.stop(); playing=false; } }
      else {
        if(sv!=null && (curVol<0 || Math.abs(lv-curVol)>=6)){ sv.setLevel(lv); curVol=lv; }
        if(!playing){ stat.start(); playing=true; }
      }
    }catch(Throwable t){}
  }
  static void playSiren(){
    if(!on||siren==null) return;
    try{ radio(0); siren.stop(); siren.setMediaTime(0); siren.start(); }catch(Throwable t){}
  }
  static void tone(int note,int dur,int vol){
    if(!on) return;
    try{ Manager.playTone(note,dur,vol); }catch(Throwable t){}
  }
  static void stopAll(){ radio(0); try{ if(siren!=null) siren.stop(); }catch(Throwable t){} }
}
