import javax.microedition.lcdui.*;
import javax.microedition.lcdui.game.*;
import javax.microedition.rms.*;
import java.io.*;
import java.util.*;

/** Сивогір'я — головний ігровий клас. MIDP 2.0 / CLDC 1.1. */
public class G extends GameCanvas implements Runnable {
  static final int K_UP=1,K_DN=2,K_LF=4,K_RT=8,K_FIRE=16,K_1=32,K_3=64,K_7=128,K_9=256,K_0=512,K_ST=1024,K_PD=2048,K_LS=4096,K_RS=8192;
  static final int S_TITLE=0,S_PLAY=1,S_TEXT=2,S_INV=3,S_SAFE=4,S_TUNE=5,S_PAUSE=6,S_DEAD=7,S_CUT=8,S_MAP=9,S_OPTS=10,S_HELP=11;
  static final int A_NONE=0,A_RUST=1,A_TITLE=2,A_START=3;
  static final int TL=Graphics.TOP|Graphics.LEFT, TC=Graphics.TOP|Graphics.HCENTER;
  static final int[] E_HP={60,36,26,420}, E_SPD={9,24,19,7}, E_DMG={12,8,6,16};
  static final int[] E_DET={5*256,7*256,6*256,14*256};

  Main mid; Thread th; volatile boolean running; boolean paused;
  int W,H; boolean sizeDirty=true;
  Font fS,fB,fT; int lh;
  Random rnd=new Random();
  int tick, held, pressed, pk;
  int st=S_TITLE, menu, optsFrom, helpFrom, pauseSel;
  boolean oSound=true,oVib=true,oFast=false,oIso=false;

  int map; boolean rust; char[][] tl; int mw,mh,theme; boolean dark;
  Vector obs=new Vector();
  Ent[] en=new Ent[24]; int ne;
  int px,py,fdx=-181,fdy=-181,sdir=1,anim; boolean walking;
  int hp=100,weapon=-1; int[] inv=new int[Lv.NI]; long flags; boolean flash;
  int atkT,shotT,invT,hurtT,tx2,ty2,toastT,nameT,fadeT,endT,bellN,radioLv;
  String toast="";
  int ox,oy;
  String[][] chunks; int chunk,afterAct,textRet;
  int[] safeD=new int[4]; int safeCur; int freq=1000;
  int invSel;
  Image fbuf; int fbx,fby,fbw,fbh; boolean fdirty=true;
  static final int MX=64,MY=40;
  int ovKey=-1;
  boolean hasSave;

  public G(Main m){
    super(false);
    mid=m;
    setFullScreenMode(true);
    fS=Font.getFont(Font.FACE_PROPORTIONAL,Font.STYLE_PLAIN,Font.SIZE_SMALL);
    fB=Font.getFont(Font.FACE_PROPORTIONAL,Font.STYLE_BOLD,Font.SIZE_SMALL);
    fT=Font.getFont(Font.FACE_PROPORTIONAL,Font.STYLE_BOLD,Font.SIZE_LARGE);
    lh=fS.getHeight();
  }
  void start(){ running=true; th=new Thread(this); th.start(); }
  void stop(){ running=false; Snd.stopAll(); }
  void pauseGame(){ paused=true; Snd.stopAll(); if(st==S_PLAY) st=S_PAUSE; }
  void resume(){ paused=false; }
  protected void hideNotify(){ if(st==S_PLAY){ st=S_PAUSE; pauseSel=0; } Snd.radio(0); }
  protected void sizeChanged(int w,int h){ sizeDirty=true; }

  // ---------------- Клавіші ----------------
  protected void keyPressed(int k){ int b=mapKey(k); synchronized(this){ held|=b; pressed|=b; } }
  protected void keyReleased(int k){ int b=mapKey(k); synchronized(this){ held&=~b; } }
  int mapKey(int k){
    switch(k){
      case KEY_NUM2: return K_UP; case KEY_NUM8: return K_DN; case KEY_NUM4: return K_LF; case KEY_NUM6: return K_RT;
      case KEY_NUM5: return K_FIRE; case KEY_NUM1: return K_1; case KEY_NUM3: return K_3; case KEY_NUM7: return K_7;
      case KEY_NUM9: return K_9; case KEY_NUM0: return K_0; case KEY_STAR: return K_ST; case KEY_POUND: return K_PD;
      case -6: case -21: return K_LS;
      case -7: case -22: return K_RS;
    }
    int ga=0; try{ ga=getGameAction(k); }catch(Exception e){}
    switch(ga){ case UP: return K_UP; case DOWN: return K_DN; case LEFT: return K_LF; case RIGHT: return K_RT; case FIRE: return K_FIRE; }
    return 0;
  }
  boolean p(int m){ return (pk&m)!=0; }

  // ---------------- Цикл ----------------
  public void run(){
    Gfx.sprites();
    loadOpts();
    Snd.on=oSound;
    Snd.init();
    hasSave=checkSave();
    Graphics g=null;
    while(running){
      long t0=System.currentTimeMillis();
      if(sizeDirty||g==null){ W=getWidth(); H=getHeight(); g=getGraphics(); sizeDirty=false; ovKey=-1; fbuf=null; fdirty=true; }
      if(!paused){
        synchronized(this){ pk=pressed; pressed=0; }
        try{ update(); render(g); }catch(Throwable e){ e.printStackTrace(); }
        flushGraphics();
      }
      long dt=System.currentTimeMillis()-t0;
      try{ Thread.sleep(dt<45?50-dt:5); }catch(Exception e){}
    }
  }

  void update(){
    tick++;
    if(toastT>0) toastT--;
    if(fadeT>0&&st!=S_PLAY) fadeT--;
    switch(st){
      case S_TITLE: updTitle(); break;
      case S_PLAY: updPlay(); break;
      case S_TEXT: case S_CUT: if(p(K_FIRE|K_LS|K_ST)) nextChunk(); break;
      case S_INV: updInv(); break;
      case S_SAFE: updSafe(); break;
      case S_TUNE: updTune(); break;
      case S_PAUSE: updPause(); break;
      case S_DEAD: updDead(); break;
      case S_MAP: if(pk!=0) st=S_PLAY; break;
      case S_OPTS: updOpts(); break;
      case S_HELP: if(pk!=0) st=helpFrom; break;
    }
    if(st!=S_PLAY && st!=S_TEXT) Snd.radio(0);
  }

  // ---------------- Текст ----------------
  void msg(String s){ msg(s,A_NONE,S_PLAY); }
  void msg(String s,int act,int ret){ chunks=paginate(s,W-16,H>=200?4:3); chunk=0; afterAct=act; textRet=ret; st=S_TEXT; }
  void cut(String s,int act){ chunks=paginate(s,W-20,(H-40)/lh); chunk=0; afterAct=act; st=S_CUT; }
  void nextChunk(){
    chunk++;
    if(chunk>=chunks.length){
      int a=afterAct; afterAct=A_NONE;
      st=(st==S_CUT)?S_PLAY:textRet;
      doAct(a);
    }
  }
  void doAct(int a){
    switch(a){
      case A_RUST:
        rust=true; setFlag(Lv.F_RUST);
        int sx=px,sy=py; loadMap(Lv.CHURCH); px=sx; py=sy;
        msg(Lv.RUST_MSG); break;
      case A_TITLE: st=S_TITLE; menu=0; hasSave=checkSave(); break;
      case A_START: st=S_PLAY; nameT=60; msg(Lv.START_MSG); break;
    }
  }
  String[] split(String s,char c){
    Vector v=new Vector(); int st0=0;
    for(int i=0;i<=s.length();i++){ if(i==s.length()||s.charAt(i)==c){ v.addElement(s.substring(st0,i)); st0=i+1; } }
    String[] o=new String[v.size()]; v.copyInto(o); return o;
  }
  Vector wrap(String s,int w){
    Vector out=new Vector(); String[] ws=split(s,' '); StringBuffer line=new StringBuffer();
    for(int i=0;i<ws.length;i++){
      String t=ws[i]; if(t.length()==0) continue;
      String cand=line.length()==0?t:line.toString()+" "+t;
      if(fS.stringWidth(cand)>w && line.length()>0){ out.addElement(line.toString()); line=new StringBuffer(t); }
      else { line=new StringBuffer(cand); }
    }
    if(line.length()>0) out.addElement(line.toString());
    return out;
  }
  String[][] paginate(String s,int w,int ml){
    if(ml<1) ml=1;
    Vector out=new Vector(); String[] pg=split(s,'|');
    for(int i=0;i<pg.length;i++){
      Vector ls=wrap(pg[i],w);
      for(int j=0;j<ls.size();j+=ml){
        int n=Math.min(ml,ls.size()-j); String[] c=new String[n];
        for(int q=0;q<n;q++) c[q]=(String)ls.elementAt(j+q);
        out.addElement(c);
      }
    }
    String[][] r=new String[out.size()][]; out.copyInto(r); return r;
  }
  void toast(String s){ toast=s; toastT=40; }

  // ---------------- Прапорці ----------------
  boolean flag(int f){ return f>=0 && (flags&(1L<<f))!=0; }
  void setFlag(int f){ if(f>=0) flags|=(1L<<f); }
  int pages(){ int n=0; if(flag(Lv.F_PAGE1))n++; if(flag(Lv.F_PAGE2))n++; if(flag(Lv.F_PAGE3))n++; if(flag(Lv.F_PAGE4))n++; return n; }

  // ---------------- Світ ----------------
  static int DBG=-1;
  void newGame(){
    flags=0; for(int i=0;i<Lv.NI;i++) inv[i]=0;
    hp=100; weapon=-1; flash=false; rust=false; bellN=0; endT=0;
    loadMap(Lv.STREET); px=10*256+128; py=23*256+128; fdx=-181; fdy=-181; sdir=1;
    if(DBG>=0){ inv[0]=1; inv[1]=1; inv[2]=50; inv[3]=1; inv[4]=1; weapon=1; flash=true;
      int[][] d={{1,0,12,12},{2,0,7,11},{0,1,7,3},{3,1,13,7},{3,1,10,4}};
      rust=d[DBG][1]==1; if(DBG==4){ setFlag(Lv.F_POWER); setFlag(Lv.F_TUNED); setFlag(Lv.F_HALL); setFlag(Lv.F_STUDIO); setFlag(Lv.F_BOSSINTRO);} 
      loadMap(d[DBG][0]); px=d[DBG][2]*256+128; py=d[DBG][3]*256+128; }
  }
  boolean worldOk(int w){ return w==0||(w==1&&!rust)||(w==2&&rust); }
  void loadMap(int m){
    map=m;
    String[] rows=Lv.rows(m,rust); mh=rows.length; mw=rows[0].length();
    tl=new char[mh][]; for(int i=0;i<mh;i++) tl[i]=rows[i].toCharArray();
    theme=Lv.theme(m,rust); dark=theme!=0;
    obs=Lv.objs(m);
    for(int i=obs.size()-1;i>=0;i--){
      Ob o=(Ob)obs.elementAt(i);
      if(!worldOk(o.w)||(o.t==Lv.O_ITEM&&flag(o.c))){ obs.removeElementAt(i); continue; }
      if(o.t==Lv.O_LOCK&&flag(o.c)) tl[o.y][o.x]=',';
    }
    Gfx.theme(theme);
    ne=0; int[][] sp=Lv.ens(m);
    for(int i=0;i<sp.length;i++) if(worldOk(sp[i][3])) spawn(sp[i][0],sp[i][1]*256+128,sp[i][2]*256+128);
    fdirty=true; ovKey=-1; nameT=50; fadeT=6; atkT=0; shotT=0;
    System.gc();
  }
  Ent spawn(int t,int x,int y){
    if(ne>=en.length) return null;
    Ent e=new Ent(); e.type=t; e.x=x; e.y=y; e.hp=e.max=E_HP[t]; e.anim=rnd.nextInt(32);
    en[ne++]=e; return e;
  }
  boolean isFloor(char c){ return c=='.'||c==','; }
  boolean solid(int x,int y){
    if(x<0||y<0) return true;
    int tx=x>>8, ty=y>>8;
    if(tx>=mw||ty>=mh) return true;
    return !isFloor(tl[ty][tx]);
  }
  boolean box(int x,int y,int r){ return solid(x-r,y-r)||solid(x+r,y-r)||solid(x-r,y+r)||solid(x+r,y+r); }
  void mv(Ent e,int dx,int dy,int r){
    int nx=e.x+dx; if(!box(nx,e.y,r)) e.x=nx;
    int ny=e.y+dy; if(!box(e.x,ny,r)) e.y=ny;
  }
  void mvP(int dx,int dy){
    int nx=px+dx; if(!box(nx,py,64)) px=nx;
    int ny=py+dy; if(!box(px,ny,64)) py=ny;
  }
  int isq(int v){ return v<=0?0:(int)Math.sqrt(v); }
  void openTile(int x,int y){ tl[y][x]=','; fdirty=true; }

  // ---------------- Гра ----------------
  void updPlay(){
    if(fadeT>0) fadeT--;
    if(nameT>0) nameT--;
    if(invT>0) invT--;
    if(hurtT>0) hurtT--;
    if(shotT>0) shotT--;
    if(endT>0){ endT--; if(endT==0){ ending(); return; } }

    if(p(K_ST|K_LS)){ st=S_INV; invSel=0; return; }
    if(p(K_RS)){ st=S_PAUSE; pauseSel=0; return; }
    if(p(K_PD|K_7)){ st=S_MAP; return; }
    if(p(K_0)){
      if(inv[Lv.I_FLASH]>0){ flash=!flash; Snd.tone(flash?96:84,30,50); toast(flash?"Ліхтарик увімкнено":"Ліхтарик вимкнено"); }
      else toast("Немає ліхтарика");
    }
    if(p(K_1)) quickHeal();
    if(p(K_3)) switchWeapon();

    int mx=0,my=0;
    boolean u=(held&K_UP)!=0,d=(held&K_DN)!=0,l=(held&K_LF)!=0,r=(held&K_RT)!=0;
    if(oIso){ if(u)my-=256; if(d)my+=256; if(l)mx-=256; if(r)mx+=256; }
    else { if(u){mx-=256;my-=256;} if(d){mx+=256;my+=256;} if(l){mx-=256;my+=256;} if(r){mx+=256;my-=256;} }
    if((held&K_9)!=0) my-=256; if((held&K_7)!=0&&false) mx-=256;
    walking=false;
    if(mx!=0||my!=0){
      int len=isq(mx*mx+my*my); mx=mx*256/len; my=my*256/len;
      fdx=mx; fdy=my;
      if(atkT==0){ mvP(mx*18>>8,my*18>>8); walking=true; anim++; }
      int sdx=fdx-fdy, sdy=fdx+fdy;
      if(Math.abs(sdx)>Math.abs(sdy)) sdir=sdx>0?2:3; else sdir=sdy>0?0:1;
    }

    if(atkT>0){
      atkT--;
      if(weapon==0&&atkT==5) melee(22,300);
      if(weapon<0&&atkT==4) melee(7,250);
    }
    if(p(K_FIRE)&&atkT==0){
      Ob o=findOb(); Ent e=nearEnemy(weapon==1?(o!=null&&o.t==Lv.O_ITEM?600:1100):330);
      if(o!=null&&e==null) interact(o);
      else attack();
    }

    updEnemies();

    // Бос
    if(map==Lv.RADIO&&flag(Lv.F_TUNED)&&!flag(Lv.F_BOSS)&&py<6*256&&px>=6*256){
      boolean has=false; for(int i=0;i<ne;i++) if(en[i].type==Lv.E_BOSS&&en[i].alive) has=true;
      if(!has){
        spawn(Lv.E_BOSS,8*256+128,2*256+128);
        Snd.tone(30,400,100);
        if(!flag(Lv.F_BOSSINTRO)){ setFlag(Lv.F_BOSSINTRO); msg(Lv.BOSS_INTRO); }
      }
    }

    // Радіо
    radioLv=0;
    if(inv[Lv.I_RADIO]>0){
      int best=7*256;
      for(int i=0;i<ne;i++){ Ent e=en[i]; if(!e.alive) continue; int dd=isq((e.x-px)*(e.x-px)+(e.y-py)*(e.y-py)); if(dd<best) best=dd; }
      if(best<7*256) radioLv=(7*256-best)*100/(7*256);
    }
    if((tick&3)==0) Snd.radio(radioLv);
  }

  void quickHeal(){
    if(hp>=100){ toast("Здоров'я в нормі"); return; }
    if(inv[Lv.I_DRINK]>0) useItem(Lv.I_DRINK);
    else if(inv[Lv.I_MED]>0) useItem(Lv.I_MED);
    else toast("Нічим лікуватися");
  }
  void switchWeapon(){
    // Коло: кулаки -> труба -> пістолет -> кулаки.
    // Не підібрані види пропускаються, кулаки завжди доступні.
    int[] order={-1,0,1}; int at=0;
    for(int i=0;i<order.length;i++) if(order[i]==weapon) at=i;
    for(int k=1;k<=order.length;k++){
      int w=order[(at+k)%order.length];
      if(w==-1 || (w==0&&inv[Lv.I_PIPE]>0) || (w==1&&inv[Lv.I_PISTOL]>0)){
        weapon=w; break;
      }
    }
    toast(weapon==1?"Пістолет":weapon==0?"Труба":"Кулаки");
  }

  Ent nearEnemy(int range){
    Ent b=null; int bd=range;
    for(int i=0;i<ne;i++){ Ent e=en[i]; if(!e.alive) continue; int d=isq((e.x-px)*(e.x-px)+(e.y-py)*(e.y-py)); if(d<bd){ bd=d; b=e; } }
    return b;
  }
  Ob findOb(){
    Ob best=null; int bs=1<<30;
    for(int i=0;i<obs.size();i++){
      Ob o=(Ob)obs.elementAt(i);
      int dx=o.x*256+128-px, dy=o.y*256+128-py; int d2=dx*dx+dy*dy;
      if(d2>330*330) continue;
      int d=isq(d2); int dot=d==0?256:(dx*fdx+dy*fdy)/d;
      if(d>210&&dot<70) continue;
      int sc=d-dot/2; if(sc<bs){ bs=sc; best=o; }
    }
    return best;
  }

  void attack(){
    if(weapon==1){ shoot(); return; }
    atkT=weapon==0?10:7;
    Snd.tone(weapon==0?50:45,25,40);
  }
  void melee(int dmg,int range){
    boolean hit=false;
    for(int i=0;i<ne;i++){
      Ent e=en[i]; if(!e.alive) continue;
      int dx=e.x-px, dy=e.y-py, d=isq(dx*dx+dy*dy);
      if(d>range+(e.type==Lv.E_BOSS?120:0)) continue;
      int dot=d==0?256:(dx*fdx+dy*fdy)/d;
      if(d>110&&dot<60) continue;
      damage(e,dmg,fdx*44>>8,fdy*44>>8); hit=true;
    }
    if(hit) Snd.tone(38,60,90);
  }
  void shoot(){
    if(inv[Lv.I_AMMO]<=0){
      toast("Немає набоїв"); Snd.tone(100,15,60);
      if(inv[Lv.I_PIPE]>0) weapon=0; atkT=5; return;
    }
    inv[Lv.I_AMMO]--; atkT=7; shotT=3; Snd.tone(28,80,100);
    Ent best=null; int bs=1<<30;
    for(int i=0;i<ne;i++){
      Ent e=en[i]; if(!e.alive) continue;
      int dx=e.x-px, dy=e.y-py, d=isq(dx*dx+dy*dy);
      if(d>6*256) continue;
      int dot=d==0?256:(dx*fdx+dy*fdy)/d;
      if(dot<120) continue;
      int sc=d-dot*3; if(sc<bs){ bs=sc; best=e; }
    }
    if(best!=null){
      int dx=best.x-px, dy=best.y-py, d=isq(dx*dx+dy*dy);
      if(d>0){ fdx=dx*256/d; fdy=dy*256/d; }
      damage(best,30,fdx*30>>8,fdy*30>>8); tx2=best.x; ty2=best.y;
    } else {
      int x=px,y=py;
      for(int s=0;s<24;s++){ x+=fdx>>2; y+=fdy>>2; if(solid(x,y)) break; }
      tx2=x; ty2=y;
    }
  }
  void damage(Ent e,int dmg,int kx,int ky){
    e.hp-=dmg; e.hit=5; e.aggro=true;
    if(e.type!=Lv.E_BOSS){ e.stun=6; e.kx=kx; e.ky=ky; e.lungeT=0; }
    if(e.hp<=0){
      e.alive=false; e.dieT=16;
      Snd.tone(e.type==Lv.E_BOSS?24:33,200,90);
      if(e.type==Lv.E_BOSS){ setFlag(Lv.F_BOSS); endT=50; for(int i=0;i<ne;i++) if(en[i].alive){ en[i].alive=false; en[i].dieT=16; } }
    }
  }
  void hurt(int dmg,Ent from){
    if(invT>0||endT>0) return;
    hp-=dmg; invT=16; hurtT=6;
    if(oVib) try{ Display.getDisplay(mid).vibrate(120); }catch(Throwable t){}
    Snd.tone(36,90,100);
    if(from!=null){
      int dx=px-from.x, dy=py-from.y, d=isq(dx*dx+dy*dy);
      if(d>0) mvP(dx*40/d,dy*40/d);
    }
    if(hp<=0){ hp=0; st=S_DEAD; menu=0; hasSave=checkSave(); Snd.radio(0); }
  }

  void updEnemies(){
    for(int i=0;i<ne;i++){
      Ent e=en[i];
      if(!e.alive){ if(e.dieT>0) e.dieT--; continue; }
      e.anim++; if(e.hit>0) e.hit--; if(e.cd>0) e.cd--;
      int dx=px-e.x, dy=py-e.y, d=isq(dx*dx+dy*dy);
      int ux=d>0?dx*256/d:0, uy=d>0?dy*256/d:0;
      int det=E_DET[e.type]+(flash&&dark?2*256:0);
      if(!e.aggro&&d<det) e.aggro=true;
      if(e.aggro&&d>det*2) e.aggro=false;
      int sdx=dx-dy; if(sdx!=0) e.face=sdx>0?1:-1;
      int rad=e.type==Lv.E_BOSS?110:(e.type==Lv.E_FLYER?50:70);
      if(e.kx!=0||e.ky!=0){ mv(e,e.kx,e.ky,rad); e.kx=e.kx*2/3; e.ky=e.ky*2/3; }
      if(e.stun>0){ e.stun--; continue; }
      if(!e.aggro){
        if(--e.wander<=0){ e.wander=30+rnd.nextInt(40); int a=rnd.nextInt(5); e.wdx=a==0?6:a==1?-6:0; e.wdy=a==2?6:a==3?-6:0; }
        mv(e,e.wdx,e.wdy,rad); continue;
      }
      int spd=E_SPD[e.type];
      switch(e.type){
        case Lv.E_HOLLOW:
          if(d>150) mv(e,ux*spd>>8,uy*spd>>8,rad);
          if(d<190&&e.cd==0){ e.cd=26; hurt(E_DMG[0],e); }
          break;
        case Lv.E_HOUND:
          if(e.lungeT>0){
            e.lungeT--; mv(e,e.ldx*52>>8,e.ldy*52>>8,rad);
            if(d<130){ hurt(E_DMG[1],e); e.lungeT=0; e.stun=8; }
          } else if(d<2*256&&d>90&&e.cd==0){ e.lungeT=7; e.ldx=ux; e.ldy=uy; e.cd=30; e.stun=3; }
          else mv(e,ux*spd>>8,uy*spd>>8,rad);
          break;
        case Lv.E_FLYER:
          if(e.retreat>0){ e.retreat--; mv(e,-ux*14>>8,-uy*14>>8,rad); }
          else {
            int wob=((e.anim>>3)&1)==0?1:-1;
            mv(e,(ux*spd-uy*wob*12)>>8,(uy*spd+ux*wob*12)>>8,rad);
            if(d<120&&e.cd==0){ hurt(E_DMG[2],e); e.cd=20; e.retreat=12; }
          }
          break;
        case Lv.E_BOSS:
          if(d>220) mv(e,ux*spd>>8,uy*spd>>8,rad);
          if(d<230&&e.cd==0){ e.cd=30; hurt(E_DMG[3],e); }
          if(e.waveR>=0){
            e.waveR+=22;
            if(!e.waveHit&&Math.abs(d-e.waveR)<70){ e.waveHit=true; hurt(10,null); }
            if(e.waveR>900) e.waveR=-1;
          } else if(--e.waveCd<=0){ e.waveCd=70+rnd.nextInt(30); e.waveR=0; e.waveHit=false; Snd.tone(26,250,80); }
          if(--e.spawnCd<=0){
            e.spawnCd=160; int nf=0;
            for(int k=0;k<ne;k++) if(en[k].alive&&en[k].type==Lv.E_FLYER) nf++;
            if(nf<2){ Ent f=spawn(Lv.E_FLYER,e.x,e.y+200); if(f!=null) f.aggro=true; }
          }
          break;
      }
    }
    // Розштовхування
    for(int i=0;i<ne;i++){ Ent a=en[i]; if(!a.alive) continue;
      for(int j=i+1;j<ne;j++){ Ent b=en[j]; if(!b.alive) continue;
        int dx=b.x-a.x, dy=b.y-a.y;
        if(Math.abs(dx)<170&&Math.abs(dy)<170){ int sx=dx>0?6:-6, sy=dy>0?6:-6; mv(a,-sx,-sy,60); mv(b,sx,sy,60); }
      }
    }
    // Чистка мертвих
    int k=0; for(int i=0;i<ne;i++){ if(en[i].alive||en[i].dieT>0) en[k++]=en[i]; } for(int i=k;i<ne;i++) en[i]=null; ne=k;
  }

  // ---------------- Взаємодія ----------------
  void interact(Ob o){
    switch(o.t){
      case Lv.O_ITEM: {
        setFlag(o.c); inv[o.a]+=o.b; obs.removeElement(o);
        if(o.a==Lv.I_PISTOL){ inv[Lv.I_AMMO]+=6; weapon=1; }
        if(o.a==Lv.I_PIPE&&weapon<0) weapon=0;
        if(o.a==Lv.I_FLASH) flash=true;
        Snd.tone(88,60,60);
        String n=Lv.NAMES[o.a]; if(o.a==Lv.I_PAGES) n="Сторінка щоденника";
        msg("Знайдено: "+n+(o.b>1?" ("+o.b+")":"")+".|"+o.s);
      } break;
      case Lv.O_NOTE: msg(o.s); break;
      case Lv.O_DOOR:
        if(o.d>=0&&!flag(o.e)){
          if(inv[o.d]>0){ setFlag(o.e); Snd.tone(70,50,60); msg("Ключ підходить. Двері відчинено."); }
          else { Snd.tone(40,40,60); msg(o.s); }
        } else { Snd.tone(55,80,50); goMap(o.a,o.b,o.c); }
        break;
      case Lv.O_LOCK: {
        String[] pr=split(o.s,'|');
        boolean ok=o.a>=0?inv[o.a]>0:flag(o.b);
        if(ok){ setFlag(o.c); openTile(o.x,o.y); obs.removeElement(o); Snd.tone(70,60,60); msg(pr.length>1?pr[1]:"Відчинено."); }
        else { Snd.tone(40,40,60); msg(pr[0]); }
      } break;
      case Lv.O_SAVE: save(); hasSave=true; Snd.tone(76,120,50); msg(Lv.SAVE_MSG); break;
      case Lv.O_SAFE:
        if(flag(Lv.F_SAFE)) msg("Сейф порожній.");
        else { st=S_SAFE; safeCur=0; for(int i=0;i<4;i++) safeD[i]=0; }
        break;
      case Lv.O_BELL: ring(o.a); break;
      case Lv.O_PANEL:
        if(flag(Lv.F_POWER)) msg("Щит рівно гуде. Живлення є.");
        else if(inv[Lv.I_FUSE]>=2){ inv[Lv.I_FUSE]=0; setFlag(Lv.F_POWER); setFlag(Lv.F_STUDIO); openTile(8,9); removeLock(8,9); Snd.tone(40,300,80); msg(Lv.POWER_MSG); }
        else if(inv[Lv.I_FUSE]==1) msg("Електрощит. У ньому два порожні гнізда, а запобіжник у тебе лише один.");
        else msg("Електрощит. Двох запобіжників бракує.");
        break;
      case Lv.O_CONSOLE:
        if(!flag(Lv.F_POWER)) msg("Пульт мовчить. Немає живлення.");
        else if(flag(Lv.F_TUNED)) msg("На всіх частотах - лише рівне шипіння.");
        else { st=S_TUNE; }
        break;
    }
  }
  void removeLock(int x,int y){
    for(int i=obs.size()-1;i>=0;i--){ Ob o=(Ob)obs.elementAt(i); if(o.t==Lv.O_LOCK&&o.x==x&&o.y==y) obs.removeElementAt(i); }
  }
  void goMap(int m,int tx,int ty){
    loadMap(m); px=tx*256+128; py=ty*256+128;
    if(m==Lv.STREET&&rust&&!flag(Lv.F_RUSTMSG)){ setFlag(Lv.F_RUSTMSG); msg("Вулиця змінилася до невпізнання. Дорогу роз'їли провали, а кузов машини біля провулка зник."); }
  }
  void ring(int b){
    if(rust){ msg("Мотузки перетворилися на іржавий дріт. Дзвони мовчать."); return; }
    int[] notes={84,72,62,61};
    Snd.tone(notes[b],700,90);
    if(Lv.BELL_ORDER[bellN]==b){
      bellN++;
      if(bellN==4){ bellN=0; Snd.playSiren(); cut(Lv.RUST_CUT,A_RUST); }
      else toast("Дзвонить "+Lv.BELLS[b]+" дзвін...");
    } else {
      boolean was=bellN>0;
      bellN=(b==Lv.BELL_ORDER[0])?1:0;
      if(was) msg("Дзвонить "+Lv.BELLS[b]+" дзвін... Звуки зливаються у фальшивий акорд і змовкають. Схоже, порядок неправильний.");
      else toast("Дзвонить "+Lv.BELLS[b]+" дзвін...");
    }
  }
  void ending(){
    Snd.radio(0);
    boolean good=pages()>=4;
    String s=good?Lv.END_GOOD:Lv.END_BAD;
    if(!good) s+="|Знайдено сторінок щоденника: "+pages()+" з 4. Збери всі, щоб почути інший фінал.";
    cut(s+"|"+Lv.CREDITS,A_TITLE);
  }

  // ---------------- Речі ----------------
  int[] invList(){
    int n=0; for(int i=0;i<Lv.NI;i++) if(inv[i]>0) n++;
    int[] l=new int[n]; n=0; for(int i=0;i<Lv.NI;i++) if(inv[i]>0) l[n++]=i; return l;
  }
  void updInv(){
    int[] l=invList();
    if(p(K_ST|K_LS|K_RS)){ st=S_PLAY; return; }
    if(l.length==0) return;
    if(invSel>=l.length) invSel=l.length-1;
    if(p(K_UP)) invSel=(invSel+l.length-1)%l.length;
    if(p(K_DN)) invSel=(invSel+1)%l.length;
    if(p(K_FIRE)) useItem(l[invSel]);
  }
  void useItem(int it){
    switch(it){
      case Lv.I_MED: if(hp>=100){ toast("Здоров'я в нормі"); return; } hp=Math.min(100,hp+60); inv[it]--; Snd.tone(80,80,60); toast("Аптечку використано"); break;
      case Lv.I_DRINK: if(hp>=100){ toast("Здоров'я в нормі"); return; } hp=Math.min(100,hp+25); inv[it]--; Snd.tone(80,80,60); toast("Ти випив гарячого чаю"); break;
      case Lv.I_PIPE: weapon=0; toast("Труба в руках"); break;
      case Lv.I_PISTOL: weapon=1; toast("Пістолет у руках"); break;
      case Lv.I_FLASH: flash=!flash; toast(flash?"Ліхтарик увімкнено":"Ліхтарик вимкнено"); break;
      case Lv.I_LETTER: msg(Lv.LETTER_TXT,A_NONE,S_INV); break;
      case Lv.I_PAGES: {
        StringBuffer sb=new StringBuffer(); int[] f={Lv.F_PAGE1,Lv.F_PAGE2,Lv.F_PAGE3,Lv.F_PAGE4};
        for(int i=0;i<4;i++) if(flag(f[i])){ if(sb.length()>0) sb.append('|'); sb.append("Сторінка "+(i+1)+": "+Lv.PAGES[i]); }
        msg(sb.toString(),A_NONE,S_INV);
      } break;
      default: msg(Lv.DESC[it],A_NONE,S_INV);
    }
  }

  // ---------------- Головоломки ----------------
  void updSafe(){
    if(p(K_ST|K_LS|K_RS)){ st=S_PLAY; return; }
    if(p(K_LF)) safeCur=(safeCur+3)%4;
    if(p(K_RT)) safeCur=(safeCur+1)%4;
    if(p(K_UP)){ safeD[safeCur]=(safeD[safeCur]+1)%10; Snd.tone(90,15,40); }
    if(p(K_DN)){ safeD[safeCur]=(safeD[safeCur]+9)%10; Snd.tone(90,15,40); }
    if(p(K_FIRE)){
      if(safeD[0]==3&&safeD[1]==9&&safeD[2]==1&&safeD[3]==6){
        setFlag(Lv.F_SAFE); inv[Lv.I_BELLKEY]=1; Snd.tone(76,200,70); st=S_PLAY; msg(Lv.SAFE_OK);
      } else { Snd.tone(40,120,70); toast("Неправильний код"); }
    }
  }
  void updTune(){
    if(p(K_ST|K_LS|K_RS)){ st=S_PLAY; return; }
    if((held&K_LF)!=0&&(p(K_LF)||(tick&1)==0)) freq=Math.max(875,freq-1);
    if((held&K_RT)!=0&&(p(K_RT)||(tick&1)==0)) freq=Math.min(1080,freq+1);
    if(p(K_UP)) freq=Math.min(1080,freq+10);
    if(p(K_DN)) freq=Math.max(875,freq-10);
    int df=Math.abs(freq-947);
    Snd.radio(df==0?15:Math.max(20,100-df*3));
    if(p(K_FIRE)){
      if(freq==947){ Snd.radio(0); setFlag(Lv.F_TUNED); setFlag(Lv.F_HALL); openTile(12,6); removeLock(12,6); st=S_PLAY; msg(Lv.TUNED_MSG); }
      else toast("Лише шипіння...");
    }
  }

  // ---------------- Меню ----------------
  String[] titleItems(){ return hasSave?new String[]{"Нова гра","Продовжити","Налаштування","Довідка","Вихід"}:new String[]{"Нова гра","Налаштування","Довідка","Вихід"}; }
  void updTitle(){
    String[] it=titleItems();
    if(p(K_UP)) menu=(menu+it.length-1)%it.length;
    if(p(K_DN)) menu=(menu+1)%it.length;
    if(p(K_FIRE|K_LS)){
      String s=it[menu];
      if(s.equals("Нова гра")){ newGame(); cut(Lv.INTRO,A_START); }
      else if(s.equals("Продовжити")){ if(load()) { st=S_PLAY; } }
      else if(s.equals("Налаштування")){ optsFrom=S_TITLE; menu=0; st=S_OPTS; }
      else if(s.equals("Довідка")){ helpFrom=S_TITLE; st=S_HELP; }
      else if(s.equals("Вихід")){ running=false; mid.quit(); }
    }
  }
  void updPause(){
    String[] it={"Продовжити","Довідка","Налаштування","Головне меню"};
    if(p(K_UP)) pauseSel=(pauseSel+3)%4;
    if(p(K_DN)) pauseSel=(pauseSel+1)%4;
    if(p(K_RS)){ st=S_PLAY; return; }
    if(p(K_FIRE|K_LS)){
      switch(pauseSel){
        case 0: st=S_PLAY; break;
        case 1: helpFrom=S_PAUSE; st=S_HELP; break;
        case 2: optsFrom=S_PAUSE; menu=0; st=S_OPTS; break;
        case 3: st=S_TITLE; menu=0; hasSave=checkSave(); break;
      }
    }
  }
  void updOpts(){
    if(p(K_UP)) menu=(menu+4)%5;
    if(p(K_DN)) menu=(menu+1)%5;
    if(p(K_ST|K_RS)){ saveOpts(); st=optsFrom; menu=0; return; }
    if(p(K_FIRE|K_LF|K_RT|K_LS)){
      switch(menu){
        case 0: oSound=!oSound; Snd.on=oSound; if(!oSound) Snd.stopAll(); break;
        case 1: oVib=!oVib; break;
        case 2: oFast=!oFast; ovKey=-1; break;
        case 3: oIso=!oIso; break;
        case 4: if(p(K_FIRE|K_LS)){ saveOpts(); st=optsFrom; menu=0; } break;
      }
    }
  }
  void updDead(){
    if(p(K_FIRE)){
      if(hasSave&&load()) st=S_PLAY;
      else { newGame(); st=S_PLAY; nameT=60; }
    }
    if(p(K_ST|K_RS|K_LS)){ st=S_TITLE; menu=0; }
  }

  // ---------------- Збереження ----------------
  void save(){
    try{
      ByteArrayOutputStream bo=new ByteArrayOutputStream(); DataOutputStream o=new DataOutputStream(bo);
      o.writeInt(2); o.writeInt(map); o.writeBoolean(rust); o.writeInt(px); o.writeInt(py); o.writeInt(hp);
      o.writeLong(flags); for(int i=0;i<Lv.NI;i++) o.writeInt(inv[i]); o.writeInt(weapon); o.writeBoolean(flash);
      byte[] d=bo.toByteArray();
      RecordStore rs=RecordStore.openRecordStore("syvsave",true);
      if(rs.getNumRecords()==0) rs.addRecord(d,0,d.length); else rs.setRecord(1,d,0,d.length);
      rs.closeRecordStore();
    }catch(Exception e){ toast("Помилка збереження"); }
  }
  boolean load(){
    try{
      RecordStore rs=RecordStore.openRecordStore("syvsave",false);
      byte[] d=rs.getRecord(1); rs.closeRecordStore();
      DataInputStream in=new DataInputStream(new ByteArrayInputStream(d));
      if(in.readInt()!=2) return false;
      int m=in.readInt(); rust=in.readBoolean(); int x=in.readInt(), y=in.readInt(); hp=in.readInt();
      flags=in.readLong(); for(int i=0;i<Lv.NI;i++) inv[i]=in.readInt(); weapon=in.readInt(); flash=in.readBoolean();
      bellN=0; endT=0; loadMap(m); px=x; py=y; nameT=60;
      return true;
    }catch(Exception e){ return false; }
  }
  boolean checkSave(){
    try{ RecordStore rs=RecordStore.openRecordStore("syvsave",false); int n=rs.getNumRecords(); rs.closeRecordStore(); return n>0; }
    catch(Exception e){ return false; }
  }
  void saveOpts(){
    try{
      byte[] d={(byte)(oSound?1:0),(byte)(oVib?1:0),(byte)(oFast?1:0),(byte)(oIso?1:0)};
      RecordStore rs=RecordStore.openRecordStore("syvopt",true);
      if(rs.getNumRecords()==0) rs.addRecord(d,0,4); else rs.setRecord(1,d,0,4);
      rs.closeRecordStore();
    }catch(Exception e){}
  }
  void loadOpts(){
    try{
      RecordStore rs=RecordStore.openRecordStore("syvopt",false); byte[] d=rs.getRecord(1); rs.closeRecordStore();
      oSound=d[0]!=0; oVib=d[1]!=0; oFast=d[2]!=0; oIso=d[3]!=0;
    }catch(Exception e){}
  }

  // ================= РЕНДЕР =================
  void render(Graphics g){
    g.setClip(0,0,W,H);
    switch(st){
      case S_TITLE: drawTitle(g); return;
      case S_CUT: drawCut(g); return;
      case S_OPTS: drawOpts(g); return;
      case S_HELP: drawHelp(g); return;
      case S_MAP: drawMap(g); return;
      case S_DEAD: drawDead(g); return;
    }
    int base=st==S_TEXT?textRet:st;
    if(base==S_INV) drawInv(g);
    else { drawWorld(g); drawHud(g); }
    if(st==S_TEXT) drawBox(g);
    else if(st==S_SAFE) drawSafe(g);
    else if(st==S_TUNE) drawTune(g);
    else if(st==S_PAUSE) drawPause(g);
  }

  void shadowText(Graphics g,String s,int x,int y,int anchor,int col){
    g.setColor(0); g.drawString(s,x+1,y+1,anchor); g.setColor(col); g.drawString(s,x,y,anchor);
  }
  void grain(Graphics g,int n){
    for(int i=0;i<n;i++){ g.setColor((i&1)==0?0x000000:0x9a9a9a); g.fillRect(rnd.nextInt(W),rnd.nextInt(H),1,1); }
  }
  void frame(Graphics g,int x,int y,int w,int h){
    g.setColor(0x080808); g.fillRect(x,y,w,h); g.setColor(0x6a6a6a); g.drawRect(x,y,w-1,h-1); g.setColor(0x2a2a2a); g.drawRect(x+1,y+1,w-3,h-3);
  }

  void drawWorld(Graphics g){
    if(fadeT>0){ g.setColor(0); g.fillRect(0,0,W,H); return; }
    int psx=W/2, psy=H/2+12;
    ox=psx-(((px-py)*16)>>8); oy=psy-(((px+py)*8)>>8);
    // Підлога (буфер)
    if(fbuf==null){ fbw=W+2*MX; fbh=H+2*MY; fbuf=Image.createImage(fbw,fbh); fdirty=true; }
    int ddx=ox-fbx, ddy=oy-fby;
    if(fdirty||ddx<-MX+4||ddx>MX-4||ddy<-MY+4||ddy>MY-4){ renderFloor(); fbx=ox; fby=oy; fdirty=false; ddx=0; ddy=0; }
    g.drawImage(fbuf,ddx-MX,ddy-MY,TL);
    // Предмети (відблиск)
    for(int i=0;i<obs.size();i++){
      Ob o=(Ob)obs.elementAt(i); if(o.t!=Lv.O_ITEM) continue;
      int sx=(o.x-o.y)*16+ox, sy=(o.x+o.y)*8+8+oy;
      if(!isFloor(tl[o.y][o.x])) continue;
      drawGlint(g,sx,sy,o.x*3+o.y);
    }
    // Сортування сутностей
    int n=0; int[] dep=new int[ne+1]; int[] idx=new int[ne+1];
    dep[n]=px+py; idx[n]=-1; n++;
    for(int i=0;i<ne;i++){ dep[n]=en[i].x+en[i].y; idx[n]=i; n++; }
    for(int i=1;i<n;i++){ int dv=dep[i], iv=idx[i], j=i-1; while(j>=0&&dep[j]>dv){ dep[j+1]=dep[j]; idx[j+1]=idx[j]; j--; } dep[j+1]=dv; idx[j+1]=iv; }
    int k=0;
    for(int d=0;d<=mw+mh-2;d++){
      int lim=(d+1)<<8;
      while(k<n&&dep[k]<lim){ drawEntity(g,idx[k]); k++; }
      int t0=Math.max(0,d-mh+1), t1=Math.min(mw-1,d);
      for(int tx=t0;tx<=t1;tx++){
        int ty=d-tx; char c=tl[ty][tx];
        if(isFloor(c)||c=='X') continue;
        int sx=(tx-ty)*16+ox, sy=(tx+ty)*8+oy;
        if(sx+48<0||sx-48>W||sy+16<0||sy-112>H) continue;
        drawProp(g,c,tx,ty,sx,sy,psx,psy);
      }
    }
    while(k<n){ drawEntity(g,idx[k]); k++; }
    // Предмети на меблях
    for(int i=0;i<obs.size();i++){
      Ob o=(Ob)obs.elementAt(i); if(o.t!=Lv.O_ITEM||isFloor(tl[o.y][o.x])) continue;
      Image im=Gfx.prop[tl[o.y][o.x]]; int hh=im!=null?im.getHeight()-16:10;
      drawGlint(g,(o.x-o.y)*16+ox,(o.x+o.y)*8+8+oy-hh,o.x*3+o.y);
    }
    // Ефекти
    if(shotT>1){ g.setColor(0xfff0a0); g.drawLine(psx,psy-9,sxOf(tx2,ty2),syOf(tx2,ty2)-8); }
    for(int i=0;i<ne;i++){ Ent e=en[i]; if(e.alive&&e.type==Lv.E_BOSS&&e.waveR>=0){
      int a=e.waveR*17>>8, b=e.waveR*17>>9; int sx=sxOf(e.x,e.y), sy=syOf(e.x,e.y);
      g.setColor(0xc04030); g.drawArc(sx-a,sy-b,2*a,2*b,0,360); g.setColor(0x601810); g.drawArc(sx-a-1,sy-b-1,2*a+2,2*b+2,0,360);
    } }
    // Туман / темрява
    int mode=theme==0?1:(flash&&inv[Lv.I_FLASH]>0?2:3);
    int key=mode*4+(oFast?1:0)+(rust?2:0);
    if(key!=ovKey){
      ovKey=key; int col=theme==0?0xb0b4b8:(rust?0x0a0202:0x000000);
      if(mode==1) Gfx.overlay(W,H,col,30,114,255,oFast,1);
      else if(mode==2) Gfx.overlay(W,H,col,40,110,255,oFast,2);
      else Gfx.overlay(W,H,col,11,54,248,oFast,3);
    }
    int cx=psx, cy=psy-8;
    if(mode==2){ int sfx=fdx-fdy, sfy=(fdx+fdy)>>1; int len=isq(sfx*sfx+sfy*sfy); if(len>0){ cx+=sfx*24/len; cy+=sfy*24/len; } }
    Image ov=Gfx.ov; int qw=Gfx.qw, qh=Gfx.qh;
    g.drawRegion(ov,0,0,qw,qh,Sprite.TRANS_NONE,cx-qw,cy-qh,TL);
    g.drawRegion(ov,0,0,qw,qh,Sprite.TRANS_MIRROR,cx,cy-qh,TL);
    g.drawRegion(ov,0,0,qw,qh,Sprite.TRANS_MIRROR_ROT180,cx-qw,cy,TL);
    g.drawRegion(ov,0,0,qw,qh,Sprite.TRANS_ROT180,cx,cy,TL);
    grain(g,theme==0?30:50);
  }
  int sxOf(int x,int y){ return (((x-y)*16)>>8)+ox; }
  int syOf(int x,int y){ return (((x+y)*8)>>8)+oy; }

  void renderFloor(){
    Graphics g=fbuf.getGraphics();
    g.setColor(Gfx.bg); g.fillRect(0,0,fbw,fbh);
    int bx=ox+MX, by=oy+MY;
    for(int ty=0;ty<mh;ty++) for(int tx=0;tx<mw;tx++){
      char c=tl[ty][tx];
      if(c=='#'||c=='D'||c=='E') continue;
      int sx=(tx-ty)*16+bx, sy=(tx+ty)*8+by;
      if(sx+16<0||sx-16>fbw||sy+16<0||sy>fbh) continue;
      Image im=c=='X'?Gfx.pit:(c=='.'?Gfx.floor[(tx*7+ty*13)&1]:Gfx.floor[2+((tx*5+ty*3)&1)]);
      g.drawImage(im,sx-16,sy,TL);
    }
  }
  void drawGlint(Graphics g,int sx,int sy,int ph){
    int t=(tick+ph*5)&31;
    g.setColor(0x9f8b67); g.fillRect(sx-3,sy-2,6,3);
    if(t<12){ g.setColor(0xffffff); g.drawLine(sx-4,sy-4,sx+4,sy-4); g.drawLine(sx,sy-8,sx,sy+1); g.setColor(0xd8c99a); g.fillRect(sx-1,sy-6,3,4); }
  }
  void drawWorldAsset(Graphics g,Image im,int sx,int groundY){
    if(im==null) return;
    g.drawImage(im,sx-im.getWidth()/2,groundY-im.getHeight(),TL);
  }
  void drawProp(Graphics g,char c,int tx,int ty,int sx,int sy,int psx,int psy){
    if(c=='T'&&Gfx.tree!=null){ drawWorldAsset(g,Gfx.tree,sx,sy+8); return; }
    if(c=='L'&&Gfx.lamp!=null){ drawWorldAsset(g,Gfx.lamp,sx,sy+8); return; }
    if(c=='R'&&Gfx.bell!=null){ drawWorldAsset(g,Gfx.bell,sx,sy+8); return; }
    if(c=='K'&&Gfx.kiosk!=null){ drawWorldAsset(g,Gfx.kiosk,sx,sy+8); return; }
    if(c=='P'&&Gfx.phonebooth!=null){ drawWorldAsset(g,Gfx.phonebooth,sx,sy+8); return; }
    if(c=='M'&&Gfx.console!=null){ drawWorldAsset(g,Gfx.console,sx,sy+8); return; }
    if(c=='O'&&Gfx.speaker!=null){ drawWorldAsset(g,Gfx.speaker,sx,sy+8); return; }
    if(c=='Q'&&Gfx.controlPanel!=null){ drawWorldAsset(g,Gfx.controlPanel,sx,sy+8); return; }
    if(c=='S'&&Gfx.bookshelf!=null){ drawWorldAsset(g,Gfx.bookshelf,sx,sy+8); return; }
    if((c=='='||c=='b')&&Gfx.counter!=null){ drawWorldAsset(g,Gfx.counter,sx,sy+8); return; }
    if(c=='p'&&Gfx.pew!=null){ drawWorldAsset(g,Gfx.pew,sx,sy+8); return; }
    if(c=='A'&&Gfx.altar!=null){ drawWorldAsset(g,Gfx.altar,sx,sy+8); return; }
    if(c=='V'&&Gfx.vending!=null){ drawWorldAsset(g,Gfx.vending,sx,sy+8); return; }
    if(c=='C'&&Gfx.car!=null){ drawWorldAsset(g,Gfx.car,sx,sy+8); return; }
    if(c=='B'){
      boolean group=tx>0&&ty>0&&tl[ty][tx-1]=='B'&&tl[ty-1][tx]=='B'&&tl[ty-1][tx-1]=='B';
      if(group&&Gfx.bus!=null){ drawWorldAsset(g,Gfx.bus,sx,sy+8); return; }
      boolean covered=(tx>0&&tl[ty][tx-1]=='B')||(ty>0&&tl[ty-1][tx]=='B')||
        (tx+1<mw&&tl[ty][tx+1]=='B')||(ty+1<mh&&tl[ty+1][tx]=='B');
      if(covered) return;
    }
    Image im=Gfx.prop[c]; if(im==null) return;
    int h=im.getHeight()-16;
    if(c=='#'||c=='D'||c=='E'){
      int dep=(tx+ty+1)<<8;
      if(dep>px+py+40 && sx+16>psx-11 && sx-16<psx+11 && sy-h<psy && sy+16>psy-40){ im=Gfx.wallCut; h=5; }
    }
    g.drawImage(im,sx-16,sy-h,TL);
    if(c=='M'){ int on=(tick>>2)&3; g.setColor(on==0?0xff2010:0x601008); g.fillRect(sx-8,sy-h+18,3,3); g.setColor(on==2?0xff2010:0x601008); g.fillRect(sx+6,sy-h+18,3,3); }
    if(c=='E'&&h>4){ g.setColor((tick&8)!=0?0xe02010:0x601008); g.fillRect(sx-10,sy-h+16,3,3); }
  }
  void drawEntity(Graphics g,int i){
    if(i<0){ drawPlayer(g); return; }
    Ent e=en[i];
    int sx=sxOf(e.x,e.y), sy=syOf(e.x,e.y);
    if(sx<-80||sx>W+80||sy<-100||sy>H+100) return;
    if(!e.alive&&(e.dieT&2)!=0) return;
    if(e.hit>0&&(e.hit&1)!=0) return;
    switch(e.type){
      case Lv.E_HOLLOW: {
        Image im=Gfx.hol[(e.anim>>3)&3]; if(im==null) return;
        int sw=((e.anim>>3)&1)==0?0:1;
        g.drawRegion(im,0,0,im.getWidth(),im.getHeight(),e.face<0?Sprite.TRANS_MIRROR:Sprite.TRANS_NONE,sx+sw,sy+1,Graphics.BOTTOM|Graphics.HCENTER);
      } break;
      case Lv.E_HOUND: {
        Image im=Gfx.hnd[(e.lungeT>0||e.aggro)?((e.anim>>1)&3):((e.anim>>3)&3)]; if(im==null) return;
        g.drawRegion(im,0,0,im.getWidth(),im.getHeight(),e.face<0?Sprite.TRANS_MIRROR:Sprite.TRANS_NONE,sx,sy+1,Graphics.BOTTOM|Graphics.HCENTER);
      } break;
      case Lv.E_FLYER: {
        Image im=Gfx.fly[(e.anim>>1)&3]; if(im==null) return;
        int bob=((e.anim>>2)&3)==0?1:0;
        g.drawImage(im,sx,sy-10-bob,Graphics.BOTTOM|Graphics.HCENTER);
      } break;
      case Lv.E_BOSS: drawBoss(g,e,sx,sy); break;
    }
  }
  void drawBoss(Graphics g,Ent e,int sx,int sy){
    Image im=Gfx.boss[(e.anim>>2)&3];
    if(im!=null) g.drawImage(im,sx,sy+1,Graphics.BOTTOM|Graphics.HCENTER);
    int bh=im==null?42:im.getHeight(), bw=38, by=sy-bh-5;
    g.setColor(0x100707); g.fillRect(sx-bw/2,by,bw,4);
    g.setColor(0x5a1710); g.drawRect(sx-bw/2,by,bw-1,3);
    g.setColor(0xd02a18); g.fillRect(sx-bw/2+1,by+1,(bw-2)*Math.max(0,e.hp)/e.max,2);
  }
  int attackFrame(int total){
    int elapsed=total-atkT, f;
    if(total==7){
      if(elapsed<1) f=0; else if(elapsed<3) f=1; else if(elapsed<5) f=2; else f=3;
    } else f=elapsed*4/total;
    if(f<0) f=0; if(f>3) f=3; return f;
  }
  void drawPlayer(Graphics g){
    int sx=W/2, sy=H/2+12;
    if(invT>0&&(invT&2)!=0) return;
    int fr=walking?((anim>>2)&3):0;
    int dir=sdir==3?2:sdir;
    int tr=sdir==3?Sprite.TRANS_MIRROR:Sprite.TRANS_NONE;
    Image im=null;
    if(atkT>0){
      if(weapon==0) im=Gfx.pipeSwing[dir][attackFrame(10)];
      else if(weapon==1) im=Gfx.pistolFire[dir][shotT>1?1:0];
      else im=Gfx.punch[dir][attackFrame(7)];
    } else if(weapon==0) im=Gfx.pipeHold[dir];
    else if(weapon==1) im=Gfx.pistolHold[dir];
    else if(walking) im=Gfx.pl[dir][fr];
    else im=Gfx.idle[dir][(tick/12)%3];
    if(im==null) im=Gfx.pl[dir][fr];
    if(im!=null) g.drawRegion(im,0,0,im.getWidth(),im.getHeight(),tr,sx,sy+1,Graphics.BOTTOM|Graphics.HCENTER);

    int sfx=fdx-fdy, sfy=(fdx+fdy)>>1, len=isq(sfx*sfx+sfy*sfy); if(len==0) len=1;
    if(flash&&dark&&inv[Lv.I_FLASH]>0){ g.setColor(0xfff8c0); g.fillRect(sx-1+sfx*2/len,sy-20,2,2); }
  }

  void drawHud(Graphics g){
    if(fadeT>0){ shadowText(g,Lv.name(map,rust),W/2,H/2-lh/2,TC,0xc0c0c0); return; }
    g.setColor(0); g.fillRect(2,2,40,7); g.setColor(0x707070); g.drawRect(2,2,39,6);
    int c=hp>60?0x3c9c3c:hp>30?0xb0a030:((tick&4)!=0?0xd02020:0x801010);
    g.setColor(c); g.fillRect(4,4,hp*36/100,3);
    g.setFont(fS);
    String ws=weapon==1?("Пістолет "+inv[Lv.I_AMMO]):weapon==0?"Труба":"Кулаки";
    shadowText(g,ws,3,H-lh-1,TL,0xc8c8c8);
    if(inv[Lv.I_FLASH]>0&&flash){ g.setColor(0xe8d870); g.fillRect(46,3,6,5); g.setColor(0x806020); g.fillRect(44,4,2,3); }
    if(radioLv>0){
      int bw=22,bx=W-bw-3; g.setColor(0); g.fillRect(bx,2,bw,9); g.setColor(0x705030); g.drawRect(bx,2,bw-1,8);
      int nn=radioLv/4+2; for(int i=0;i<nn;i++){ g.setColor(rnd.nextInt(2)==0?0xe0e0e0:0x808080); g.fillRect(bx+1+rnd.nextInt(bw-2),3+rnd.nextInt(7),1,1); }
      if(radioLv>60&&(tick&2)!=0){ g.setColor(0xd02020); g.fillRect(bx-4,4,2,5); }
    }
    if(nameT>0) shadowText(g,Lv.name(map,rust),W/2,14,TC,0xd0d0d0);
    if(toastT>0) shadowText(g,toast,W/2,nameT>0?14+lh:14,TC,0xf0e0a0);
    if(hurtT>0){ g.setColor(0xa01010); for(int i=0;i<3;i++) g.drawRect(i,i,W-1-2*i,H-1-2*i); }
    if(st==S_PLAY){ shadowText(g,"Речі",W-2,H-lh-1,Graphics.TOP|Graphics.RIGHT,0x808080); }
  }

  void drawBox(Graphics g){
    if(chunks==null||chunk>=chunks.length) return;
    String[] ls=chunks[chunk]; int n=H>=200?4:3;
    int bh=n*lh+10, by=H-bh-2;
    frame(g,3,by,W-6,bh);
    g.setFont(fS); g.setColor(0xd8d8d0);
    for(int i=0;i<ls.length;i++) g.drawString(ls[i],8,by+5+i*lh,TL);
    if((tick&8)!=0){ g.setColor(0xa0a0a0); int ax=W-12, ay=by+bh-7; g.fillTriangle(ax,ay,ax+6,ay,ax+3,ay+3); }
  }
  void drawCut(Graphics g){
    g.setColor(0); g.fillRect(0,0,W,H);
    if(chunks==null||chunk>=chunks.length) return;
    String[] ls=chunks[chunk]; g.setFont(fS);
    int th2=ls.length*lh, y=(H-th2)/2;
    for(int i=0;i<ls.length;i++){ g.setColor(0xc8c4bc); g.drawString(ls[i],W/2,y+i*lh,TC); }
    // Show the user's Nina sprite on the ending credits page.
    if(afterAct==A_TITLE&&chunk==chunks.length-1&&Gfx.nina!=null)
      g.drawImage(Gfx.nina,W/2,H-8,Graphics.BOTTOM|Graphics.HCENTER);
    if((tick&8)!=0){ g.setColor(0x707070); g.drawString("5 >",W-4,H-lh-2,Graphics.TOP|Graphics.RIGHT); }
    grain(g,40);
  }

  void drawTitle(Graphics g){
    for(int i=0;i<H;i+=4){ g.setColor(Gfx.mix(0x16181c,0x5a5e64,i*256/H)); g.fillRect(0,i,W,4); }
    int base=H*3/5;
    if(Gfx.titleCity!=null)
      g.drawImage(Gfx.titleCity,(W-Gfx.titleCity.getWidth())/2,base-Gfx.titleCity.getHeight(),Graphics.LEFT|Graphics.TOP);
    g.setColor(0x121316); g.fillRect(0,base,W,H-base);
    for(int k=0;k<6;k++){
      int y=base-18+k*5, dir=(k&1)==0?1:-1; g.setColor(Gfx.mix(0x5a5e64,0x9a9ea4,k*40));
      for(int x=-12;x<W;x+=12){ int xx=x+((tick*dir+k*17)%12); if(((x/12+k)%3)!=0) g.fillRect(xx,y,8,1); }
    }
    g.setFont(fT);
    if(rnd.nextInt(40)!=0){ shadowText(g,"СИВОГІР'Я",W/2,H/7,TC,0xd0ccc4); }
    g.setFont(fS); shadowText(g,"тиша в тумані",W/2,H/7+fT.getHeight(),TC,0x8a2a20);
    String[] it=titleItems();
    int y=base+6;
    for(int i=0;i<it.length;i++){
      boolean s=i==menu; g.setFont(s?fB:fS);
      shadowText(g,s?"> "+it[i]+" <":it[i],W/2,y+i*(lh+1),TC,s?0xffffff:0x8a8a8a);
    }
    grain(g,60);
  }
  void drawOpts(Graphics g){
    g.setColor(0x0a0a0a); g.fillRect(0,0,W,H);
    g.setFont(fB); shadowText(g,"НАЛАШТУВАННЯ",W/2,8,TC,0xd0d0d0);
    String[] it={"Звук: "+(oSound?"увімк.":"вимк."),"Вібрація: "+(oVib?"увімк.":"вимк."),"Туман: "+(oFast?"швидкий":"плавний"),
      "Керування: "+(oIso?"ізометр.":"екранне"),"Назад"};
    for(int i=0;i<it.length;i++){ boolean s=i==menu; g.setFont(s?fB:fS); shadowText(g,(s?"> ":"")+it[i],12,30+i*(lh+3),TL,s?0xffffff:0x909090); }
    g.setFont(fS);
    String hint=menu==2?"Швидкий туман - для слабких телефонів.":menu==3?"Екранне: 2 = вгору екрана. Ізометр.: 2 = по діагоналі.":"5 - змінити, * - назад";
    Vector w=wrap(hint,W-16); for(int i=0;i<w.size();i++) shadowText(g,(String)w.elementAt(i),8,H-(w.size()-i)*lh-4,TL,0x707070);
  }
  void drawHelp(Graphics g){
    g.setColor(0x0a0a0a); g.fillRect(0,0,W,H);
    g.setFont(fB); shadowText(g,"КЕРУВАННЯ",W/2,4,TC,0xd0d0d0);
    String[] l={"2 4 6 8 / джойстик - рух","5 - дія, удар, постріл","1 - швидке лікування","3 - змінити зброю",
      "0 - ліхтарик","* / ліва софт - речі","# / 7 - мапа","права софт - пауза","","Радіо шипить, коли поруч","монстри. Телефон-автомат","зберігає гру."};
    g.setFont(fS); for(int i=0;i<l.length;i++) shadowText(g,l[i],6,6+lh+i*lh,TL,0xa0a0a0);
  }
  void drawMap(Graphics g){
    g.setColor(0x0c0a08); g.fillRect(0,0,W,H);
    g.setFont(fB); shadowText(g,"МАПА: "+Lv.name(map,rust),W/2,3,TC,0xc8c0b0);
    int s=Math.max(2,Math.min((W-8)/(mw+mh),(H-30)*2/(mw+mh)));
    int cx=W/2-(mw-mh)*s/2, cy=(H-((mw+mh)*s)/2)/2+8;
    for(int ty=0;ty<mh;ty++) for(int tx=0;tx<mw;tx++){
      char c=tl[ty][tx]; int x=cx+(tx-ty)*s/1, y=cy+(tx+ty)*s/2;
      int col;
      if(c=='#') col=0x5a5048; else if(c=='D'||c=='E'||c=='G') col=0xc07020; else if(isFloor(c)) col=0x2a2620; else if(c=='X') col=0x000000; else col=0x7a6a50;
      if(c=='P') col=0x4060c0;
      g.setColor(col); g.fillRect(x-s/2,y,s,Math.max(1,s/2));
    }
    if((tick&4)!=0){ int x=cx+((px-py)*s>>8), y=cy+((px+py)*s>>9); g.setColor(0xff2020); g.fillRect(x-2,y-1,4,3); }
    g.setFont(fS); shadowText(g,"Синій - телефон, жовтий - двері",W/2,H-lh-2,TC,0x707070);
  }
  void drawInv(Graphics g){
    g.setColor(0x0c0c0c); g.fillRect(0,0,W,H);
    g.setFont(fB); shadowText(g,"РЕЧІ",6,3,TL,0xd0d0d0);
    String sts=hp>60?"Добре":hp>30?"Обережно":"Небезпека"; int sc=hp>60?0x40b040:hp>30?0xc0b030:0xd03020;
    g.setFont(fS); shadowText(g,"Стан: "+sts,W-6,3,Graphics.TOP|Graphics.RIGHT,sc);
    int ey=5+lh; g.setColor(0x102010); g.fillRect(4,ey,W-8,12); g.setColor(sc);
    int prev=ey+6; int per=hp>60?16:hp>30?11:7;
    for(int x=0;x<W-10;x++){ int ph=(x+tick*2)%32; int yy=ey+6; if(ph==per) yy=ey+1; else if(ph==per+1) yy=ey+11; else if(ph==per+2) yy=ey+4; g.drawLine(4+x,prev,5+x,yy); prev=yy; }
    int[] l=invList();
    int ly=ey+16, maxv=(H-ly-3*lh-8)/lh; if(maxv<2) maxv=2;
    int top=Math.max(0,Math.min(invSel-maxv/2,l.length-maxv)); if(top<0) top=0;
    if(l.length==0) shadowText(g,"Порожньо",W/2,ly,TC,0x707070);
    for(int i=top;i<l.length&&i<top+maxv;i++){
      int it=l[i]; boolean s=i==invSel; String nm=Lv.NAMES[it];
      if(it==Lv.I_AMMO||it==Lv.I_MED||it==Lv.I_DRINK||it==Lv.I_FUSE) nm+=" x"+inv[it];
      if(it==Lv.I_PAGES) nm+=" ("+pages()+"/4)";
      if((it==Lv.I_PIPE&&weapon==0)||(it==Lv.I_PISTOL&&weapon==1)||(it==Lv.I_FLASH&&flash)) nm+=" *";
      int y=ly+(i-top)*lh;
      if(s){ g.setColor(0x3a2a20); g.fillRect(4,y,W-8,lh); }
      drawIcon(g,it,8,y+lh/2);
      shadowText(g,nm,20,y,TL,s?0xffffff:0x9a9a9a);
    }
    if(l.length>0){
      int it=l[Math.min(invSel,l.length-1)];
      Vector w=wrap(Lv.DESC[it],W-12);
      int dy=H-3*lh-4; g.setColor(0x303030); g.drawLine(4,dy-2,W-5,dy-2);
      for(int i=0;i<w.size()&&i<2;i++) shadowText(g,(String)w.elementAt(i),6,dy+i*lh,TL,0x8a8a80);
    }
    shadowText(g,"5 - використати   * - назад",W/2,H-lh-1,TC,0x606060);
  }
  void drawIcon(Graphics g,int it,int x,int y){
    if(it>=0&&it<Gfx.itemIcon.length&&Gfx.itemIcon[it]!=null){
      g.drawImage(Gfx.itemIcon[it],x,y,Graphics.HCENTER|Graphics.VCENTER); return;
    }
    int[] col={0x8a6a50,0x404448,0xc0a040,0xe0d070,0x6a5040,0xd03030,0x709060,0xb0a060,0xa08040,0xa04030,0x60a0c0,0xe0e0d0,0xd8d0b0};
    g.setColor(col[it]); g.fillRect(x-3,y-3,7,6); g.setColor(0); g.drawRect(x-3,y-3,6,5);
  }
  void drawSafe(Graphics g){
    int bw=Math.min(W-10,150), bh=70, bx=(W-bw)/2, by=(H-bh)/2;
    frame(g,bx,by,bw,bh);
    g.setFont(fB); shadowText(g,"СЕЙФ",W/2,by+4,TC,0xc0c0c0);
    g.setFont(fT);
    int dw=22, sx=W/2-2*dw;
    for(int i=0;i<4;i++){
      int x=sx+i*dw;
      g.setColor(i==safeCur?0x5a4a30:0x2a2a2a); g.fillRect(x+2,by+22,dw-4,fT.getHeight()+4);
      g.setColor(i==safeCur?0xffffff:0x909090); g.drawString(""+safeD[i],x+dw/2,by+24,TC);
    }
    g.setFont(fS); shadowText(g,"2/8 цифра, 4/6 вибір, 5 ок",W/2,by+bh-lh-3,TC,0x808080);
  }
  void drawTune(Graphics g){
    int bw=Math.min(W-8,164), bh=86, bx=(W-bw)/2, by=(H-bh)/2;
    frame(g,bx,by,bw,bh);
    g.setFont(fB); shadowText(g,"ПУЛЬТ СТУДІЇ",W/2,by+4,TC,0xc0c0c0);
    String fs=(freq/10)+"."+(freq%10)+" МГц";
    g.setFont(fT); g.setColor(0xe0a040); g.drawString(fs,W/2,by+18,TC);
    int sy2=by+22+fT.getHeight(), sx0=bx+8, sw=bw-16;
    g.setColor(0x404040); g.drawLine(sx0,sy2,sx0+sw,sy2);
    for(int f=880;f<=1080;f+=20){ int x=sx0+(f-875)*sw/205; g.drawLine(x,sy2-2,x,sy2); }
    int nx=sx0+(freq-875)*sw/205; g.setColor(0xd02020); g.fillRect(nx-1,sy2-6,2,9);
    int df=Math.abs(freq-947);
    int ny=sy2+6;
    if(df==0){ g.setColor(0x60c060); for(int x=0;x<sw;x+=2){ int yy=ny+5+((x+tick)%12<6?-3:3); g.fillRect(sx0+x,yy,2,1); } }
    else { int n=Math.min(120,20+df*2); for(int i=0;i<n;i++){ g.setColor(rnd.nextInt(2)==0?0xc0c0c0:0x606060); g.fillRect(sx0+rnd.nextInt(sw),ny+rnd.nextInt(10),1,1); } }
    g.setFont(fS); shadowText(g,"4/6 точно, 2/8 крок, 5 ок",W/2,by+bh-lh-2,TC,0x808080);
  }
  void drawPause(Graphics g){
    String[] it={"Продовжити","Довідка","Налаштування","Головне меню"};
    int bw=Math.min(W-20,130), bh=4*(lh+3)+lh+12, bx=(W-bw)/2, by=(H-bh)/2;
    frame(g,bx,by,bw,bh);
    g.setFont(fB); shadowText(g,"ПАУЗА",W/2,by+4,TC,0xc0c0c0);
    for(int i=0;i<4;i++){ boolean s=i==pauseSel; g.setFont(s?fB:fS); shadowText(g,it[i],W/2,by+8+lh+i*(lh+3),TC,s?0xffffff:0x8a8a8a); }
  }
  void drawDead(Graphics g){
    g.setColor(0x0a0000); g.fillRect(0,0,W,H);
    for(int i=0;i<H;i+=3){ g.setColor(Gfx.mix(0x200000,0x000000,i*256/H)); g.fillRect(0,i,W,2); }
    g.setFont(fT); if((tick&16)!=0||true) shadowText(g,"ТИ ЗАГИНУВ",W/2,H/3,TC,0xb01810);
    g.setFont(fS);
    shadowText(g,hasSave?"5 - від останнього дзвінка":"5 - почати знову",W/2,H/2+10,TC,0xa0a0a0);
    shadowText(g,"* - головне меню",W/2,H/2+12+lh,TC,0x707070);
    grain(g,80);
  }
}
