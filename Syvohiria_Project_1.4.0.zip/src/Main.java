import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;
public class Main extends MIDlet {
  G g;
  public void startApp(){
    if(g==null){ g=new G(this); Display.getDisplay(this).setCurrent(g); g.start(); }
    else { Display.getDisplay(this).setCurrent(g); g.resume(); }
  }
  public void pauseApp(){ if(g!=null) g.pauseGame(); }
  public void destroyApp(boolean u){ if(g!=null) g.stop(); }
  public void quit(){ destroyApp(true); notifyDestroyed(); }
}
