import java.util.Vector;
import java.io.InputStream;

/** Дані рівнів, об'єктів і тексти. Оригінальний сюжет "Сивогір'я". */
public class Lv {
  static final int STREET=0, POST=1, CHURCH=2, RADIO=3;
  static final int O_ITEM=1,O_NOTE=2,O_DOOR=3,O_LOCK=4,O_SAVE=5,O_SAFE=6,O_BELL=7,O_PANEL=8,O_CONSOLE=9;
  static final int WB=0, WF=1, WR=2;
  static final int I_PIPE=0,I_PISTOL=1,I_AMMO=2,I_FLASH=3,I_RADIO=4,I_MED=5,I_DRINK=6,I_POSTKEY=7,
    I_BELLKEY=8,I_CUTTER=9,I_FUSE=10,I_LETTER=11,I_PAGES=12, NI=13;
  static final int F_PIPE=0,F_FLASH=1,F_RADIO=2,F_POSTKEY=3,F_POSTDOOR=4,F_PISTOL=5,F_AMMO_P=6,F_MED_P=7,
    F_LETTER=8,F_SAFE=9,F_PAGE1=10,F_DRINK_S1=11,F_TOWER=12,F_PAGE2=13,F_AMMO_C=14,F_MED_C=15,F_RUST=16,
    F_CUTTER=17,F_GATE=18,F_PAGE3=19,F_AMMO_R1=20,F_MED_R1=21,F_FUSE1=22,F_FUSE2=23,F_POWER=24,F_TUNED=25,
    F_BOSSINTRO=26,F_BOSS=27,F_PAGE4=28,F_AMMO_S1=29,F_MED_S1=30,F_AMMO_S2=31,F_DRINK_P=32,F_DRINK_C=33,
    F_AMMO_R2=34,F_DRINK_S2=35,F_STUDIO=36,F_HALL=37,F_RUSTMSG=38;
  static final int E_HOLLOW=0,E_HOUND=1,E_FLYER=2,E_BOSS=3;

  static final String[] NAMES={"Труба","Пістолет","Набої","Ліхтарик","Радіо","Аптечка","Термос з чаєм",
    "Ключ від пошти","Ключ від дзвіниці","Болторіз","Запобіжник","Лист Ніни","Сторінки щоденника"};
  static final String[] DESC={
    "Іржава водопровідна труба. Краще, ніж голі руки.",
    "Службовий пістолет. Клавіша 3 - змінити зброю.",
    "Набої до пістолета.",
    "Ліхтарик водія. Клавіша 0 - увімкнути/вимкнути. Світло допомагає бачити в темряві, але й привертає увагу.",
    "Кишеньковий радіоприймач. Ловить лише шипіння... Шипіння посилюється, коли поруч щось є.",
    "Аптечка. Добре відновлює здоров'я.",
    "Термос із гарячим чаєм. Відновлює трохи сил.",
    "Ключ з биркою «Пошта».",
    "Старовинний ключ із биркою «Дзвіниця».",
    "Важкий болторіз. Ним можна перекусити ланцюг.",
    "Запобіжник. Схоже, від електрощита.",
    "Лист від Ніни, адресований тобі. Його так і не відправили.",
    "Сторінки чийогось старого щоденника."};

  static final String INTRO=
    "Осінь. Останній автобус до гірського містечка Сивогір'я петляє серпантином у густому тумані."+
    "|Три тижні тому моя сестра Ніна поїхала сюди, щоб дізнатися правду про нашу бабусю. Відтоді - жодного дзвінка."+
    "|За кілька кілометрів до міста двигун заглух. Водій пішов по допомогу... і не повернувся."+
    "|Мене звати Лука. І я не поїду звідси без неї.";
  static final String START_MSG=
    "Туман такий густий, що ледве видно власні руки. Варто оглянути автобус і все довкола."+
    "|2/4/6/8 - рух, 5 - дія або удар, * - речі, # - мапа, 0 - ліхтарик, 1 - лікування, 3 - зброя.";
  static final String LETTER_TXT=
    "«Луко, у цьому місті всі про щось мовчать. Бабуся працювала на радіостанції, коли 1974-го обвалилася шахта."+
    "|Щовечора на частоті 94.7 я чую голоси. Вони кличуть мене на станцію."+
    "|Якщо я не повернуся - не шукай мене тут. Ніна.»";
  static final String[] PAGES={
    "«12 жовтня 1974. Під землею лишилося сорок двоє. Нам наказали не говорити в ефір ні слова про шахту. Тільки музика. Тільки тиша.»",
    "«Отець Василь бив у дзвони три дні поспіль, доки йому не заборонили. Місто вирішило забути. Наступної осені прийшов туман.»",
    "«Я переписала їхні імена. Усі сорок два. Якщо хтось колись прочитає їх в ефір - може, тиша нас відпустить.»",
    "«Тиша має голос. Вона глушить кожну хвилю, що несе правду. Я назвала її Глушником. Список імен - на звороті цієї сторінки.»"};
  static final String[] BELLS={"малий","середній","великий","тріснутий"};
  static final int[] BELL_ORDER={0,2,3,1};
  static final String RUST_CUT=
    "Останній удар дзвону не стихає. Він повільно перетворюється на протяжне виття сирени."+
    "|Стіни вкриваються іржею, підлога - ґратами. Світло гасне."+
    "|Десь у цій темряві - Ніна. Тепер я в цьому певен.";
  static final String RUST_MSG="Шипіння в радіо не вщухає. Треба шукати шлях до радіостанції за хвірткою на вулиці.";
  static final String SAVE_MSG="Телефон-автомат. Ти набираєш номер Ніни... Лише шипіння в слухавці.|Гру збережено.";
  static final String SAFE_OK="Замок клацає. Усередині - старовинний ключ із биркою «Дзвіниця».";
  static final String POWER_MSG="Ти вставляєш обидва запобіжники. Глибоко в стінах щось загуло. Двері студії відчинилися.";
  static final String TUNED_MSG="Крізь шипіння проривається голос: «Луко... я в залі передавача... воно не відпускає...»|Десь у коридорі з гуркотом відчинилися важкі двері.";
  static final String BOSS_INTRO="Посеред залу - щось, зліплене з дротів, гучномовців і людських тіней. Воно шипить на всіх частотах одразу.";
  static final String END_GOOD=
    "Глушник розсипається на іржавий пил. Шипіння стихає."+
    "|Ніна лежить біля передавача - жива. Вона шепоче: «Імена... треба прочитати імена...»"+
    "|Лука вмикає мікрофон і вголос читає всі сорок два імені зі сторінок щоденника."+
    "|Над Сивогір'ям уперше за п'ятдесят років розвіюється туман. Десь далеко б'ють дзвони."+
    "|КІНЕЦЬ: «ГОЛОС».";
  static final String END_BAD=
    "Глушник розсипається на іржавий пил. Але шипіння не стихає."+
    "|Ніна стоїть біля передавача. Вона дивиться на тебе і не впізнає."+
    "|Ви йдете до виходу. Туман за дверима щільніший, ніж будь-коли."+
    "|Можливо, правду, яку ніхто не вимовив, неможливо вбити трубою."+
    "|КІНЕЦЬ: «ТИША».";
  static final String CREDITS="СИВОГІР'Я - оригінальна гра-оммаж класичному survival horror для J2ME.|Дякуємо, що грали.";

  static String name(int m,boolean rust){
    switch(m){ case POST: return "Пошта"; case CHURCH: return rust?"Церква (?)":"Церква"; case RADIO: return "Радіостанція"; }
    return rust?"Вулиця (?)":"Вулиця Ринкова";
  }
  static int theme(int m,boolean rust){
    switch(m){ case POST: return 1; case CHURCH: return rust?4:2; case RADIO: return 4; }
    return rust?3:0;
  }

  static final String[] STREET_F={
    "####################",
    "#######D############",
    "#,,,,,,,,,,,,,,,,,,#",
    "#,T,,,L,,,,,,L,,,T,#",
    "#,,,,..........,,,,#",
    "#,b,,..........,FFF#",
    "#,,,,..........,F,,#",
    "#,T,,..C.......,G,,D",
    "#,,,,..........,F,,#",
    "####,..........,FFF#",
    "####,L.........L,,,#",
    "####,..........,####",
    "###D,.......C..,####",
    "####,..........,#,,#",
    "####,..........,C,,#",
    "####,..........,#,,#",
    "####,L.........L####",
    "#,,,,..........,,,,#",
    "#,K,,..........,,P,#",
    "#,,,,..........,,,,#",
    "#,T,,....BB....,,T,#",
    "#,,,,....BB....,,,,#",
    "#,,,,..........,,,,#",
    "#,L,,..........,L,,#",
    "#,,,,..........,,,,#",
    "####################"};
  static final String[] STREET_R={
    "####################",
    "#######D############",
    "#,,,,,,,,,,,,,,,,,,#",
    "#,T,,,L,,,,,,L,,,T,#",
    "#,,,,....XX....,,,,#",
    "#,b,,..........,FFF#",
    "#,,,,..........,F,,#",
    "#,T,,..C.......,G,,D",
    "#YYY,..........,F,,#",
    "####,..........,FFF#",
    "####,L..XXXX...L,,,#",
    "####,..........,####",
    "###D,.......C..,####",
    "####,..........,#,,#",
    "####,..........,,,,#",
    "####,..........,#,,#",
    "####,XXX.......L####",
    "#,,,,..........,,,,#",
    "#,K,,..........,,P,#",
    "#,,,,..XXXXXX..,,,,#",
    "#,T,,....BB....,,T,#",
    "#,,,,....BB....,,,,#",
    "#,,,,..........,,,,#",
    "#,L,,..........,L,,#",
    "#,,,,..........,,,,#",
    "####################"};
  static final String[] POST_M={
    "##############",
    "#V,,,#S,S,S,,#",
    "#,,,,#,,,,,,,#",
    "#,,,,,,,,,,,,#",
    "#,,,,#S,,,,,,#",
    "######,,,,,,,#",
    "#,,,,,,,,,,,,#",
    "#,====,,,b,,,#",
    "#,,,,,,,,,,,,#",
    "#,,,,,,,,,,,,#",
    "##,,###,,,####",
    "#,,,,#,,,,,,,#",
    "#P,,,#,,,,,,,D",
    "##############"};
  static final String[] CHURCH_M={
    "##############",
    "#,,,,#,,,,,,,#",
    "#,R,R#,,,A,,,#",
    "#,,,,#,,,,,,,#",
    "#,RR,D,,,,,,,#",
    "#,,,,#,,,,,,,#",
    "######,pp,pp,#",
    "#,,,,,,,,,,,,#",
    "#,,,,,,pp,pp,#",
    "#,,,,,,,,,,,,#",
    "#,P,,,,pp,pp,#",
    "#,,,,,,,,,,,,#",
    "#######D######"};
  static final String[] RADIO_M={
    "################",
    "#,,,,#,,,,,,,,,#",
    "#,,,,#,,,,,,,,,#",
    "#,,,,#,,,,M,,,,#",
    "#,,,,#,,,,,,,,,#",
    "##,###,,,,,,,,,#",
    "#,,,,#######E###",
    "#,,,,,,,,,,,,,,#",
    "#,,,,,,,,,,,,,,#",
    "###,####E####,##",
    "#,,,,#,,,,#,,,P#",
    "#,,,,#,,O,#,,Q,#",
    "#,,,,#,,,,#,,,,#",
    "#,,,,#,,,,#,,,,#",
    "#,,,,#,,,,#,,,,D",
    "################"};

  static String mapFile(int m){
    switch(m){ case POST: return "post.ini"; case CHURCH: return "church.ini"; case RADIO: return "radio.ini"; }
    return "street.ini";
  }
  static String[] rows(int m,boolean rust){
    String[] ext=readMapIni(mapFile(m),rust);
    if(ext!=null) return ext;
    switch(m){ case POST: return POST_M; case CHURCH: return CHURCH_M; case RADIO: return RADIO_M; }
    return rust?STREET_R:STREET_F;
  }
  static void mapIniLine(String raw,String[] section,Vector normal,Vector other){
    String line=raw.trim();
    if(line.length()==0||line.charAt(0)==';') return;
    if(line.charAt(0)=='['&&line.charAt(line.length()-1)==']'){
      section[0]=line.substring(1,line.length()-1); return;
    }
    if(line.indexOf('=')>=0) return;
    if(section[0].equalsIgnoreCase("normal")) normal.addElement(line);
    else if(section[0].equalsIgnoreCase("rust")) other.addElement(line);
  }
  static String[] readMapIni(String file,boolean rust){
    InputStream in=null;
    try{
      in=Lv.class.getResourceAsStream("/maps/"+file);
      if(in==null) return null;
      Vector normal=new Vector(), other=new Vector();
      String[] section={""}; StringBuffer line=new StringBuffer(); int ch;
      while((ch=in.read())!=-1){
        if(ch==13) continue;
        if(ch==10){ mapIniLine(line.toString(),section,normal,other); line.setLength(0); }
        else line.append((char)ch);
      }
      if(line.length()>0) mapIniLine(line.toString(),section,normal,other);
      Vector rows=(rust&&other.size()>0)?other:normal;
      if(rows.size()==0) return null;
      int width=((String)rows.elementAt(0)).length();
      if(width==0) return null;
      String[] out=new String[rows.size()];
      for(int i=0;i<out.length;i++){
        out[i]=(String)rows.elementAt(i);
        if(out[i].length()!=width) return null;
        for(int x=0;x<width;x++) if(out[i].charAt(x)>127) return null;
      }
      return out;
    }catch(Exception e){ return null; }
    finally{ try{ if(in!=null) in.close(); }catch(Exception e){} }
  }

  static void mapObjectLine(String raw,String[] section,Vector v,int width,int height){
    String line=raw.trim();
    if(line.length()==0||line.charAt(0)==';') return;
    if(line.charAt(0)=='['&&line.charAt(line.length()-1)==']'){
      section[0]=line.substring(1,line.length()-1); return;
    }
    if(!section[0].equalsIgnoreCase("objects")) return;
    int eq=line.indexOf('='); if(eq<4||!line.substring(0,3).equalsIgnoreCase("obj")) return;
    try{
      int idx=Integer.parseInt(line.substring(3,eq).trim());
      int comma=line.indexOf(',',eq+1); if(comma<0) return;
      int x=Integer.parseInt(line.substring(eq+1,comma).trim());
      int y=Integer.parseInt(line.substring(comma+1).trim());
      if(idx<0||idx>=v.size()||x<0||x>=width||y<0||y>=height) return;
      Ob ob=(Ob)v.elementAt(idx); ob.x=x; ob.y=y;
    }catch(Exception e){}
  }
  static void applyObjectIni(int m,Vector v){
    InputStream in=null;
    try{
      in=Lv.class.getResourceAsStream("/maps/"+mapFile(m));
      if(in==null) return;
      String[] map=rows(m,false); if(map.length==0) return;
      int width=map[0].length(),height=map.length; String[] section={""};
      StringBuffer line=new StringBuffer(); int ch;
      while((ch=in.read())!=-1){
        if(ch==13) continue;
        if(ch==10){ mapObjectLine(line.toString(),section,v,width,height); line.setLength(0); }
        else line.append((char)ch);
      }
      if(line.length()>0) mapObjectLine(line.toString(),section,v,width,height);
    }catch(Exception e){}
    finally{ try{ if(in!=null) in.close(); }catch(Exception e){} }
  }

  static void o(Vector v,int t,int x,int y,int a,int b,int c,int d,int e,int w,String s){
    Ob ob=new Ob(); ob.t=t; ob.x=x; ob.y=y; ob.a=a; ob.b=b; ob.c=c; ob.d=d; ob.e=e; ob.w=w; ob.s=s; v.addElement(ob);
  }
  static void it(Vector v,int x,int y,int item,int cnt,int flag,int w,String s){ o(v,O_ITEM,x,y,item,cnt,flag,0,0,w,s); }
  static void nt(Vector v,int x,int y,int w,String s){ o(v,O_NOTE,x,y,0,0,0,0,0,w,s); }

  static Vector objs(int m){
    Vector v=new Vector();
    switch(m){
    case STREET:
      it(v,8,22,I_PIPE,1,F_PIPE,WB,DESC[I_PIPE]+" Клавіша 5 - удар.");
      it(v,9,21,I_FLASH,1,F_FLASH,WB,"На сидінні водія лежав ліхтарик. "+DESC[I_FLASH]);
      it(v,2,18,I_RADIO,1,F_RADIO,WB,"На прилавку кіоску - "+DESC[I_RADIO].toLowerCase());
      it(v,2,5,I_POSTKEY,1,F_POSTKEY,WB,"На лавці лежить ключ з биркою «Пошта». Поруч записка: «Я більше не розноситиму листи в цей туман.»");
      it(v,17,2,I_DRINK,1,F_DRINK_S1,WB,DESC[I_DRINK]);
      nt(v,6,3,WF,"Оголошення на стовпі: «ЗНИКЛИ БЕЗ ВІСТІ». Десятки облич, вицвілих від дощу. Найсвіжіше фото - Ніна.");
      nt(v,6,3,WR,"Оголошення на стовпі зотліло. Замість облич - іржаві плями.");
      o(v,O_DOOR,7,1,CHURCH,7,11,-1,-1,WB,"");
      o(v,O_DOOR,3,12,POST,12,12,I_POSTKEY,F_POSTDOOR,WF,"Двері пошти замкнено.");
      nt(v,3,12,WR,"Двері пошти вросли в іржаву стіну. Не відчинити.");
      o(v,O_LOCK,16,7,I_CUTTER,-1,F_GATE,0,0,WB,"Хвіртку до радіостанції замкнено на товстий ланцюг.|Болторіз із хрускотом перекушує ланцюг. Хвіртка відчинена.");
      o(v,O_DOOR,19,7,RADIO,14,14,-1,-1,WB,"");
      o(v,O_SAVE,17,18,0,0,0,0,0,WB,"");
      nt(v,7,7,WB,"Машина з розбитим склом. Усередині - нікого. Ключі в замку запалювання, але акумулятор мертвий.");
      nt(v,16,14,WF,"Покинута машина перегородила прохід у провулок.");
      it(v,18,13,I_CUTTER,1,F_CUTTER,WR,DESC[I_CUTTER]);
      it(v,17,15,I_PAGES,1,F_PAGE3,WR,"Сторінка щоденника (3/4): "+PAGES[2]);
      it(v,12,3,I_AMMO,10,F_AMMO_R1,WR,DESC[I_AMMO]);
      it(v,1,24,I_MED,1,F_MED_R1,WR,DESC[I_MED]);
      it(v,18,22,I_AMMO,8,F_AMMO_R2,WR,DESC[I_AMMO]);
      break;
    case POST:
      o(v,O_DOOR,13,12,STREET,4,12,-1,-1,WB,"");
      nt(v,3,2,WB,"Записка на підлозі: «Код сейфа - цифри на марках посилок. Порядок - пори року, як у календарі.»");
      nt(v,6,1,WB,"Посилка з маркою «ОСІНЬ». На марці велика цифра 6.");
      nt(v,8,1,WB,"Посилка з маркою «ЗИМА». На марці велика цифра 3.");
      nt(v,10,1,WB,"Посилка з маркою «ЛІТО». На марці велика цифра 1.");
      nt(v,6,4,WB,"Посилка з маркою «ВЕСНА». На марці велика цифра 9.");
      o(v,O_SAFE,1,1,0,0,0,0,0,WB,"");
      it(v,3,7,I_PISTOL,1,F_PISTOL,WB,"Під прилавком - службовий пістолет і кілька набоїв. Клавіша 3 - змінити зброю.");
      it(v,12,9,I_AMMO,10,F_AMMO_P,WB,DESC[I_AMMO]);
      it(v,2,11,I_MED,1,F_MED_P,WB,DESC[I_MED]);
      it(v,8,3,I_LETTER,1,F_LETTER,WB,DESC[I_LETTER]+" Його можна прочитати в меню речей (*).");
      it(v,11,11,I_PAGES,1,F_PAGE1,WB,"Сторінка щоденника (1/4): "+PAGES[0]);
      it(v,9,6,I_DRINK,1,F_DRINK_P,WB,DESC[I_DRINK]);
      o(v,O_SAVE,1,12,0,0,0,0,0,WB,"");
      break;
    case CHURCH:
      o(v,O_DOOR,7,12,STREET,7,2,-1,-1,WB,"");
      o(v,O_LOCK,5,4,I_BELLKEY,-1,F_TOWER,0,0,WB,"Двері до дзвіниці замкнено.|Старий ключ повертається зі скрипом. Двері до дзвіниці відчинено.");
      o(v,O_BELL,2,2,0,0,0,0,0,WB,"");
      o(v,O_BELL,4,2,1,0,0,0,0,WB,"");
      o(v,O_BELL,2,4,2,0,0,0,0,WB,"");
      o(v,O_BELL,3,4,3,0,0,0,0,WB,"");
      nt(v,9,2,WB,"Табличка біля вівтаря:|«Малий будить ранок, великий скликає полудень, тріснутий оплакує вечір, середній колише ніч.»");
      it(v,1,7,I_PAGES,1,F_PAGE2,WB,"Сторінка щоденника (2/4): "+PAGES[1]);
      it(v,12,11,I_MED,1,F_MED_C,WB,DESC[I_MED]);
      it(v,12,1,I_AMMO,8,F_AMMO_C,WB,DESC[I_AMMO]);
      it(v,3,9,I_DRINK,1,F_DRINK_C,WB,DESC[I_DRINK]);
      o(v,O_SAVE,2,10,0,0,0,0,0,WB,"");
      break;
    case RADIO:
      o(v,O_DOOR,15,14,STREET,18,7,-1,-1,WB,"");
      it(v,2,2,I_FUSE,1,F_FUSE1,WB,DESC[I_FUSE]);
      it(v,2,12,I_FUSE,1,F_FUSE2,WB,DESC[I_FUSE]);
      o(v,O_PANEL,13,11,0,0,0,0,0,WB,"");
      o(v,O_LOCK,8,9,-1,F_POWER,F_STUDIO,0,0,WB,"Електронний замок студії. Немає живлення.|Замок пискнув і відчинився.");
      o(v,O_CONSOLE,8,11,0,0,0,0,0,WB,"");
      o(v,O_LOCK,12,6,-1,F_TUNED,F_HALL,0,0,WB,"Важкі двері залу передавача. Не відчиняються. Здається, їх тримає щось по той бік.|Двері залу передавача з гуркотом відчиняються.");
      it(v,6,13,I_PAGES,1,F_PAGE4,WB,"Сторінка щоденника (4/4): "+PAGES[3]);
      it(v,4,8,I_AMMO,10,F_AMMO_S1,WB,DESC[I_AMMO]);
      it(v,12,13,I_MED,1,F_MED_S1,WB,DESC[I_MED]);
      it(v,4,1,I_AMMO,8,F_AMMO_S2,WB,DESC[I_AMMO]);
      it(v,1,14,I_DRINK,1,F_DRINK_S2,WB,DESC[I_DRINK]);
      o(v,O_SAVE,14,10,0,0,0,0,0,WB,"");
      nt(v,10,3,WB,"Передавач. Лампи жевріють червоним, хоча живлення давно немає.");
      break;
    }
    applyObjectIni(m,v);
    return v;
  }

  static int enemyKind(String s){
    if(s.equalsIgnoreCase("hollow")) return E_HOLLOW;
    if(s.equalsIgnoreCase("hound")) return E_HOUND;
    if(s.equalsIgnoreCase("flyer")) return E_FLYER;
    if(s.equalsIgnoreCase("boss")) return E_BOSS;
    return -1;
  }
  static int enemyWorld(String s){
    if(s.equalsIgnoreCase("interior")||s.equalsIgnoreCase("base")) return WB;
    if(s.equalsIgnoreCase("normal")) return WF;
    if(s.equalsIgnoreCase("rust")) return WR;
    return -1;
  }
  static int[][] readEnemyIni(int m){
    InputStream in=null; boolean found=false;
    try{
      in=Lv.class.getResourceAsStream("/maps/"+mapFile(m));
      if(in==null) return null;
      String[] map=rows(m,false); int width=map[0].length(),height=map.length;
      Vector enemies=new Vector(); String[] section={""}; StringBuffer line=new StringBuffer(); int ch;
      while((ch=in.read())!=-1){
        if(ch==13) continue;
        if(ch==10){
          String s=line.toString().trim(); line.setLength(0);
          if(s.length()>1&&s.charAt(0)=='['&&s.charAt(s.length()-1)==']'){
            section[0]=s.substring(1,s.length()-1); if(section[0].equalsIgnoreCase("enemies")) found=true;
          }else if(found&&section[0].equalsIgnoreCase("enemies")) addEnemyIni(s,enemies,width,height);
        }else line.append((char)ch);
      }
      String s=line.toString().trim();
      if(found&&section[0].equalsIgnoreCase("enemies")) addEnemyIni(s,enemies,width,height);
      if(!found) return null;
      int[][] out=new int[enemies.size()][4];
      for(int i=0;i<out.length;i++) out[i]=(int[])enemies.elementAt(i);
      return out;
    }catch(Exception e){ return null; }
    finally{ try{ if(in!=null) in.close(); }catch(Exception e){} }
  }
  static void addEnemyIni(String line,Vector enemies,int width,int height){
    if(line.length()==0||line.charAt(0)==';') return;
    int eq=line.indexOf('='); if(eq<0) return;
    try{
      int a=line.indexOf(',',eq+1),b=line.indexOf(',',a+1),c=line.indexOf(',',b+1);
      if(a<0||b<0||c<0) return;
      int type=enemyKind(line.substring(eq+1,a).trim());
      int x=Integer.parseInt(line.substring(a+1,b).trim());
      int y=Integer.parseInt(line.substring(b+1,c).trim());
      int world=enemyWorld(line.substring(c+1).trim());
      if(type<0||world<0||x<0||x>=width||y<0||y>=height) return;
      enemies.addElement(new int[]{type,x,y,world});
    }catch(Exception e){}
  }

  /** {type, x, y, world}; editable spawn list comes from the map INI. */
  static int[][] ens(int m){
    int[][] ext=readEnemyIni(m);
    if(ext!=null) return ext;
    switch(m){
    case STREET: return new int[][]{
      {E_HOUND,7,15,WF},{E_FLYER,10,9,WF},{E_HOLLOW,12,4,WF},{E_FLYER,3,3,WF},{E_HOUND,13,11,WF},
      {E_HOLLOW,7,17,WR},{E_HOLLOW,12,10,WR},{E_HOUND,6,6,WR},{E_HOUND,13,14,WR},{E_FLYER,9,3,WR},
      {E_FLYER,17,2,WR},{E_HOLLOW,17,14,WR},{E_HOLLOW,3,22,WR}};
    case POST: return new int[][]{{E_HOLLOW,9,2,WB},{E_HOLLOW,3,9,WB},{E_FLYER,10,8,WB}};
    case CHURCH: return new int[][]{{E_FLYER,9,4,WF},{E_HOLLOW,3,8,WF},
      {E_HOLLOW,9,3,WR},{E_HOLLOW,4,9,WR},{E_HOUND,11,9,WR},{E_FLYER,7,7,WR}};
    case RADIO: return new int[][]{{E_HOLLOW,7,7,WB},{E_HOUND,12,8,WB},{E_HOLLOW,2,12,WB},{E_HOLLOW,3,3,WB},
      {E_FLYER,8,13,WB},{E_HOUND,3,7,WB}};
    }
    return new int[0][];
  }
}
