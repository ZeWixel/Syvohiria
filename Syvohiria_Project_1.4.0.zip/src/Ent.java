public class Ent {
  int type,x,y,hp,max,cd,stun,anim,face=1,hit,dieT,kx,ky,lungeT,ldx,ldy,retreat,waveR=-1,waveCd=60,spawnCd=150,wander,wdx,wdy;
  boolean alive=true,aggro,waveHit;
}
