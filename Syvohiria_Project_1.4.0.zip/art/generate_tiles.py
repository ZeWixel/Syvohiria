#!/usr/bin/env python3
"""Export the old Gfx.java floor and block materials as editable PNGs.
Each generated image is a normal RGBA PNG placed under res/art/tiles/themeN/.
"""
from pathlib import Path
from PIL import Image

OUT = Path(__file__).resolve().parents[1] / 'res' / 'art' / 'tiles'
TW, TH, WH = 32, 16, 32


def clamp(v):
    return max(0, min(255, int(v)))


def rgb(c):
    if isinstance(c, tuple): return tuple(c[:3])
    return ((c >> 16) & 255, (c >> 8) & 255, c & 255)


def shade(c, d):
    r, g, b = rgb(c)
    return (clamp(r+d), clamp(g+d), clamp(b+d), 255)


def mix(a, b, t):
    ra, ga, ba = rgb(a); rb, gb, bb = rgb(b)
    return (clamp(ra + (((rb-ra)*t) >> 8)),
            clamp(ga + (((gb-ga)*t) >> 8)),
            clamp(ba + (((bb-ba)*t) >> 8)), 255)


def mod(v, n):
    return v % n


def save(im, path):
    path.parent.mkdir(parents=True, exist_ok=True)
    im.save(path, format='PNG', optimize=True, compress_level=9)


def floor_img(base, pat, seed):
    im = Image.new('RGBA', (TW, TH), (0, 0, 0, 0))
    px = im.load()
    for y in range(TH):
        for x in range(TW):
            a = 2*y-(TH-1); b = 2*x-(TW-1)
            edge = abs(b) + 2*abs(a)
            if edge > 35:
                continue
            c = base
            if ((x+2*y+seed)&7) == 0: c = shade(c, 2)
            if edge >= 32: c = shade(c, -16)
            elif edge >= 28 and ((x+seed)&3) == 0: c = shade(c, -7)
            if pat == 1:
                if mod(x+y+seed,9)==0 or mod(x-y+seed,9)==0: c = shade(base,-18)
                elif mod(x+y+seed,9)==1 and ((x+seed)&1)==0: c = shade(base,5)
            elif pat == 2:
                if mod(y+seed,5)==0: c = shade(base,-20)
                elif mod(x+seed,13)==0: c = shade(base,-9)
                if mod(y+seed,10)==1 and mod(x+seed,17)>8: c = shade(base,6)
            elif pat == 3:
                if (x+seed)%8==0 or (y+seed)%4==0: c = shade(base,-18)
                if (x+seed)%8==1 and (y+seed)%4==1: c = shade(base,6)
                if ((x+seed)%8 in (2,6)) and (y+seed)%4==2: c = shade(base,16)
            elif pat == 4:
                if mod(x+y+seed,10)==0 or mod(x-y+seed,10)==0: c = shade(base,-17)
                if mod(x+y+seed,10)==1 and mod(x-y+seed,10)==1: c = shade(base,7)
            elif pat == 5:
                if (x+seed)%8==0 or (y+seed)%5==0: c = shade(base,-21)
                if mod(x+seed,11)==2 and mod(y+seed,7)<2: c = mix(c,0x873e26,90)
                if mod(x+seed,17)==9 and mod(y+seed,9)==4: c = shade(c,14)
            elif pat == 6:
                if mod(x+y+seed,11)==0: c = shade(base,-17)
                if mod(x+seed,13)==3 and mod(y+seed,7)==2: c = mix(c,0x5b2419,110)
                if mod(x+seed,13)==4 and mod(y+seed,7)==2: c = mix(c,0x5b2419,110)
            else:
                q = mod(x*3+y+seed,37)
                if q==0: c = shade(base,12)
                elif q==5: c = shade(base,-12)
                if mod(x+y+seed,17)==0 and mod(y+seed,5)==1: c = shade(base,-8)
            px[x,y] = c
    if pat in (0,6):
        x = 5+mod(seed*3,21); y = 4+mod(seed*5,8)
        for xx, yy, col in ((x,y,shade(base,-23)), (x+1,y,shade(base,-18))):
            if 0<=xx<TW and 0<=yy<TH: px[xx,yy] = col
        if (seed&1)==0 and x+2<TW and y+1<TH: px[x+2,y+1] = shade(base,-16)
        x2=7+mod(seed*7,17); y2=5+mod(seed*11,7)
        if x2<TW and y2<TH: px[x2,y2] = shade(base,15)
    return im


def pit_img(base):
    im = Image.new('RGBA',(TW,TH),(0,0,0,0)); px=im.load()
    for y in range(TH):
        for x in range(TW):
            edge=abs(2*x-(TW-1))+2*abs(2*y-(TH-1))
            if edge>35: continue
            if edge>=30: c=shade(base,-13)
            elif edge>=24: c=mix(0x1b0906,base,95)
            else: c=(8,5,4,255)
            if edge>16 and edge<23 and (x%7==0 or y%5==0): c=(22,9,7,255)
            px[x,y]=c
    return im


def block(height, top, left_face, right_face, pat, ex, seed, rust, door_col=0x493321):
    h=(height*4+2)//3
    ht=TH+h
    im=Image.new('RGBA',(TW,ht),(0,0,0,0)); px=im.load()
    for x in range(TW):
        b=abs(2*x-(TW-1)); em=0
        for y in range(TH-1,-1,-1):
            if b+2*abs(2*y-(TH-1))<=35:
                em=y; break
        left=x<TW//2
        u=x if left else TW-1-x
        for y in range(ht):
            if y<TH and b+2*abs(2*y-(TH-1))<=35:
                ed=b+2*abs(2*y-(TH-1))
                c=shade(top,5) if ((x+2*y+seed)&7)==0 else rgb(top)+(255,)
                if ed>=32: c=shade(top,-16)
                elif ed>=27 and ((x+seed)&3)==0: c=shade(top,-7)
                if pat==3 and ((x+seed)%8==0 or (y+seed)%4==0): c=shade(top,-9)
                if pat==1 and (x+y+seed)%9==0: c=shade(top,-12)
            elif y>em and y<=em+h:
                v=y-em-1; base=left_face if left else right_face
                c=shade(base,3 if ((u+v+seed)&7)==0 else 0)
                if pat==1:
                    row=v//8; off=(row&1)*4
                    if v%8==7 or mod(u+off,8)==0: c=shade(base,-18)
                    elif v%8==6 and mod(u+off,8)<2: c=shade(base,-8)
                elif pat==2:
                    if v%8==0: c=shade(base,-20)
                    elif u%7==0: c=shade(base,-11)
                    elif u%13==4 and v%9==3: c=shade(base,10)
                elif pat==3:
                    if u%8==0 or v%12==0: c=shade(base,-22)
                    elif u%8==1 and v%12==1: c=shade(base,12)
                    if u in (3,12) and v%12==3: c=shade(base,24)
                    if u==15: c=shade(base,9)
                elif pat==4:
                    if ((u+v)&3)==0 or v==0 or v==h-1: c=shade(base,-15)
                elif pat==5:
                    if u%8==0 or v%12==0: c=shade(base,-20)
                    if u in (3,12) and mod(v+seed,19)<3: c=mix(c,0x8c4328,105)
                elif pat==6:
                    if v%8==0 or mod(u+(v//8)*3,10)==0: c=shade(base,-18)
                    if u==5 and mod(v+seed,17)==6: c=mix(c,0x68281b,100)
                else:
                    if mod(u+v+seed,19)==0: c=shade(base,-14)
                if ex&128:
                    fp=v%21
                    if fp in (0,1): c=shade(base,12)
                    elif fp in (19,20): c=shade(base,-13)
                if ex&64 and v>=h-4: c=shade(base,-28)
                if ex&2:
                    fp=v%21
                    win=(h>=34 and 4<=u<=11 and 4<=fp<=12) if h>=34 else (3<=u<=12 and 3<=v<h-3)
                    if win:
                        lo,hi=(4,12) if h>=34 else (3,h-4)
                        if u in (4,11) or fp in (lo,hi): c=shade(base,-26)
                        elif u in (7,8): c=shade(base,-10)
                        else:
                            glass=0x39545d if left else 0x30474f
                            c=shade(glass,(8 if fp<lo+3 else -2)+((u+fp)&3))
                            if u==5 and fp==lo+2: c=(0x9b,0xb3,0xad,255)
                            if u==9 and fp==hi-2: c=(0x18,0x26,0x2b,255)
                        if fp==hi+1: c=shade(base,-7)
                if ex&1 and u>=4 and u<=11 and v>=h-22:
                    dv=v-(h-22)
                    if u in (4,11) or dv==0: c=shade(door_col,-27)
                    else: c=shade(door_col,4 if ((u+dv)&3)==0 else -3)
                    if u==10 and dv==11: c=(176,155,105,255)
                    if u==5 and dv==19: c=shade(door_col,-20)
                if ex&4 and v>=4 and v<h-3 and (v%7)<3 and (u%6)<4:
                    c=(0x20,0x17,0x0f,255) if (u+v)%3==0 else (0x30,0x23,0x19,255)
                if ex&8 and v==4 and (u%5)==1:
                    c=(0x49,0x4b,0x48,255) if u==9 else (0xa3,0xa3,0x9a,255)
                if ex&16 and v%7==3 and u%5==1:
                    c=(0x49,0xa0,0x50,255) if (u+v)%2==0 else (0xa3,0x3a,0x30,255)
                if ex&32 and 5<=u<=10 and 4<=v<=8:
                    c=(0xa1,0xa3,0x9d,255) if u in (5,10) or v in (4,8) else (0x26,0x30,0x33,255)
                if rust and pat!=3 and u in (3,12) and mod(v+seed,27)<2:
                    c=mix(c,0x813b24,90)
                if u==15: c=shade(c,8)
                if u==0: c=shade(c,-10)
            else:
                continue
            px[x,y]=c
    return im


# Theme tuple: floor A, floor B, wall top/left/right/pattern, floor patterns, rust.
THEMES = {
    0: (0x58595a,0,0x77746e,1,0x726c62,0x5d564c,0x474138,1,0,False),
    1: (0x514235,2,0x45433d,3,0x817e71,0x666258,0x4d4a43,0,64,False),
    2: (0x484642,4,0x46443f,4,0x77736a,0x625d54,0x4a453e,1,0,False),
    3: (0x3d3027,5,0x463329,6,0x574338,0x443226,0x30241c,5,0,True),
    4: (0x352a25,5,0x3f3028,6,0x504039,0x403129,0x30251f,5,0,True),
}

TILE_NAMES = {
    '#':'wall', 'D':'door', 'E':'security_door', 'F':'low_barrier',
    'G':'gate', 'Y':'rust_block', 'C':'car_tile', 'B':'bus_tile',
    'K':'shrub_block', 'P':'blue_block', 'b':'small_block', '=':'counter_block',
    'S':'shelf_block', 'V':'vending_block', 'p':'pew_block', 'A':'altar_block',
    'M':'console_block', 'O':'speaker_block', 'Q':'control_panel_block'
}


def transform(c, rust):
    return mix(shade(c,-18),0x5a291b,105) if rust else c


def emit_theme(th):
    fa,pa,fb,pb,wt,wl,wr,wp,ex,rs=THEMES[th]
    d=OUT/f'theme{th}'; d.mkdir(parents=True,exist_ok=True)
    s=th*100
    door_col={0:0x493321,1:0x523824,2:0x3c291b,3:0x2b190f,4:0x302017}[th]
    save(floor_img(fa,pa,s+1),d/'floor0.png')
    save(floor_img(fa,pa,s+2),d/'floor1.png')
    save(floor_img(fb,pb,s+3),d/'floor2.png')
    save(floor_img(fb,pb,s+4),d/'floor3.png')
    save(pit_img(fb),d/'pit.png')
    facade=ex|2|128
    save(block(WH,wt,wl,wr,wp,facade,s+11,rs),d/'wall.png')
    save(block(WH,wt,wl,wr,wp,facade|1,s+12,rs,door_col),d/'door.png')
    save(block(4,wt,wl,wr,wp,0,s+13,rs),d/'wall_cut.png')
    save(block(WH,transform(0x515559,rs),transform(0x404447,rs),transform(0x303639,rs),3,1|128,s+14,rs,transform(0x505357,rs)),d/'security_door.png')
    save(block(13,transform(0x777a78,rs),transform(0x686b68,rs),transform(0x545755,rs),4,0,s+15,rs),d/'low_barrier.png')
    save(block(13,transform(0x887b5e,rs),transform(0x75694f,rs),transform(0x5c5039,rs),4,0,s+16,rs),d/'gate.png')
    save(block(17,0x4b3022,0x3d2519,0x2d1b13,4,0,s+17,True),d/'rust_block.png')
    save(block(9,transform(0x536066,rs),transform(0x404c50,rs),transform(0x30393d,rs),3,2,s+18,rs),d/'car_tile.png')
    save(block(20,transform(0x8a7a4a,rs),transform(0x6d6037,rs),transform(0x514729,rs),3,2,s+19,rs),d/'bus_tile.png')
    save(block(17,transform(0x486148,rs),transform(0x35513a,rs),transform(0x263e2e,rs),2,2,s+20,rs),d/'shrub_block.png')
    save(block(24,transform(0x43547a,rs),transform(0x33446a,rs),transform(0x263552,rs),3,2,s+21,rs),d/'blue_block.png')
    save(block(4,transform(0x5b452d,rs),transform(0x4b3825,rs),transform(0x3a2b1d,rs),2,0,s+22,rs),d/'small_block.png')
    save(block(9,transform(0x715333,rs),transform(0x5c442b,rs),transform(0x463520,rs),2,0,s+23,rs),d/'counter_block.png')
    save(block(20,transform(0x59452f,rs),transform(0x473824,rs),transform(0x382a1b,rs),2,4,s+24,rs),d/'shelf_block.png')
    save(block(11,transform(0x555b5e,rs),transform(0x41474a,rs),transform(0x303639,rs),3,32,s+25,rs),d/'vending_block.png')
    save(block(5,transform(0x503923,rs),transform(0x3e2d1c,rs),transform(0x302116,rs),2,0,s+26,rs),d/'pew_block.png')
    save(block(8,transform(0xbdb39f,rs),transform(0x756d5f,rs),transform(0x5a544a,rs),1,0,s+27,rs),d/'altar_block.png')
    save(block(30,transform(0x44494a,rs),transform(0x34393a,rs),transform(0x272c2d,rs),3,0,s+28,rs),d/'console_block.png')
    save(block(10,transform(0x45494a,rs),transform(0x35393a,rs),transform(0x282c2d,rs),3,8,s+29,rs),d/'speaker_block.png')
    save(block(18,transform(0x5a5d5e,rs),transform(0x484b4c,rs),transform(0x36393a,rs),3,16,s+30,rs),d/'control_panel_block.png')


if __name__=='__main__':
    for theme in range(5): emit_theme(theme)
    print('generated editable tile and facade PNGs:', sum(1 for _ in OUT.rglob('*.png')))
