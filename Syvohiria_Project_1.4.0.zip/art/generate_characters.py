#!/usr/bin/env python3
"""Normalize the user's supplied cast sprites and build missing enemy frames."""
from pathlib import Path
from PIL import Image, ImageDraw, ImageOps
from generate_art import OUT, hollow, hound, flyer

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'references' / 'user_sprites'
SOURCE_COPY = OUT / 'source'
SOURCE_COPY.mkdir(parents=True, exist_ok=True)
OUT.mkdir(parents=True, exist_ok=True)


def crop_to_32(im):
    im = im.convert('RGBA')
    if im.size == (34, 34):
        # The supplied sprites contain 32 active vertical pixels with a 1px
        # transparent border; crop the canvas without resampling the drawing.
        return im.crop((1, 1, 33, 33))
    if im.size != (32, 32):
        im = im.resize((32, 32), Image.Resampling.NEAREST)
    return im


def load_source(name):
    return crop_to_32(Image.open(SOURCE / name))


def save(im, name):
    im.save(OUT / name, format='PNG', optimize=True, compress_level=9)


# Keep a copy of the complete supplied sprite set inside the game's art tree,
# so extracting the JAR gives the user both editable outputs and source art.
for f in SOURCE.glob('*.png'):
    Image.open(f).convert('RGBA').save(SOURCE_COPY / f.name, optimize=True)

# Four-frame movement cycles: down/up directly; the side cycle is normalized
# to a right-facing base because G.java mirrors it for leftward movement.
for i in range(4):
    save(load_source(f'Player_walk_down{i+1}.png'), f'hero_d{i}.png')
    save(load_source(f'Player_walk_up{i+1}.png'), f'hero_u{i}.png')
    side = load_source(f'Player_walk_left{i+1}.png').transpose(Image.Transpose.FLIP_LEFT_RIGHT)
    save(side, f'hero_s{i}.png')

# Three supplied idle poses per view. Side idle art is already right-facing.
for i in range(3):
    save(load_source(f'Player_idle_down{i+1}.png'), f'idle_d{i}.png')
    save(load_source(f'Player_idle_up{i+1}.png'), f'idle_u{i}.png')
    save(load_source(f'Player_idle_right{i+1}.png'), f'idle_s{i}.png')

# Use the user's 32x32 Nina sprite as the in-game rescue/cutscene portrait.
save(crop_to_32(Image.open(SOURCE / 'Nina.png')), 'nina.png')

# Preserve the drawn monster's silhouette and red core while adding a few
# radio-speaker sockets and cable legs from the existing Syvohiria boss design.

def boss_frame(source_name, frame):
    src = crop_to_32(Image.open(SOURCE / source_name))
    canvas = Image.new('RGBA', (34, 42), (0, 0, 0, 0))
    canvas.alpha_composite(src, (1, 0))
    d = ImageDraw.Draw(canvas)
    sway = (-1, 0, 1, 0)[frame]
    ink = (31, 19, 21, 255)
    body_shade = (62, 24, 30, 255)
    cable = (86, 33, 37, 255)
    cable_hi = (155, 59, 49, 255)
    socket = (26, 20, 23, 255)
    red = (208, 44, 37, 255)
    gold = (226, 147, 69, 255)
    # Three radio-speaker diaphragms borrow the old boss's ringed-mouth motif,
    # while the supplied central yellow/red core and tentacle silhouette stay visible.
    for cx, cy in ((10+sway, 20), (24-sway, 20), (17, 29)):
        d.ellipse((cx-3,cy-3,cx+3,cy+3), fill=socket, outline=ink, width=1)
        d.ellipse((cx-2,cy-2,cx+2,cy+2), fill=body_shade, outline=cable)
        d.ellipse((cx-1,cy-1,cx+1,cy+1), fill=red if frame in (0,2) else cable_hi)
        d.point((cx,cy), fill=gold if (frame+cx)&1 else red)
    # Short hanging wires and split cable feet extend the body to 42px high.
    paths = [
        [(11+sway,29),(10+sway,33),(7+sway,37),(8+sway,40)],
        [(16,30),(16-sway,34),(18-sway,38),(17-sway,41)],
        [(23-sway,29),(24-sway,33),(27-sway,37),(26-sway,40)],
    ]
    for pts in paths:
        d.line(pts, fill=ink, width=3)
        d.line(pts, fill=cable, width=1)
    for x,y in ((8+sway,40),(17-sway,41),(26-sway,40)):
        d.line((x-2,y,x+1,y), fill=ink, width=2)
        d.point((x,y-2), fill=cable_hi)
    # A few asymmetrical rust seams tie the new lower silhouette to the old boss.
    d.line((5,25,8+sway,27), fill=cable_hi, width=1)
    d.line((26-sway,27,29,24), fill=body_shade, width=1)
    return canvas

for i, source_name in enumerate(('Monster1.png','Monster2.png','Monster1.png','Monster2.png')):
    boss_frame(source_name, i).save(OUT / f'boss{i}.png', optimize=True, compress_level=9)

# Build the remaining enemies in the established palette, then reduce them to
# the requested compact silhouettes: hollow h=32, hound w=32, flyer h=32.
for i in range(4):
    hollow(i)
    hound(i)
    flyer(i)

for i in range(4):
    im = Image.open(OUT / f'hollow{i}.png').convert('RGBA')
    im = im.resize((24, 32), Image.Resampling.NEAREST)
    im.save(OUT / f'hollow{i}.png', optimize=True, compress_level=9)
    im = Image.open(OUT / f'hound{i}.png').convert('RGBA')
    im = im.resize((32, 20), Image.Resampling.NEAREST)
    im.save(OUT / f'hound{i}.png', optimize=True, compress_level=9)
    im = Image.open(OUT / f'flyer{i}.png').convert('RGBA')
    im = im.resize((32, 32), Image.Resampling.NEAREST)
    im.save(OUT / f'flyer{i}.png', optimize=True, compress_level=9)

print('normalized player/Nina; generated 4-frame combat cast; user source PNGs kept in res/art/source/')
