#!/usr/bin/env python3
"""Original 16-bit horror pixel art for Syvohiria.
Inspired by the supplied sprite-sheet's readable clusters and proportions;
all characters and props are redrawn for this game, with no smoothing/dither.
"""
from pathlib import Path
from PIL import Image, ImageDraw

OUT = Path(__file__).resolve().parents[1] / 'res' / 'art'
OUT.mkdir(parents=True, exist_ok=True)
INK = (22, 22, 23, 255)
CLEAR = (0, 0, 0, 0)


def save_indexed(im, path):
    rgba = im.convert('RGBA')
    alpha = rgba.getchannel('A')
    rgb = Image.new('RGB', rgba.size, (0, 0, 0))
    rgb.paste(rgba, (0, 0), alpha)
    q = rgb.quantize(colors=63, method=Image.Quantize.FASTOCTREE,
                     dither=Image.Dither.NONE)
    ix, aa = list(q.tobytes()), list(alpha.tobytes())
    q.putdata([i if a >= 128 else 63 for i, a in zip(ix, aa)])
    pal = q.getpalette() or []
    pal += [0] * (768 - len(pal))
    pal[189:192] = [0, 0, 0]
    q.putpalette(pal[:768])
    q.info['transparency'] = 63
    q.save(path, format='PNG', optimize=True, compress_level=9, transparency=63)


class P:
    """Draw directly on the final pixel grid. No resampling."""
    def __init__(self, w, h):
        self.w, self.h = w, h
        self.im = Image.new('RGBA', (w, h), CLEAR)
        self.d = ImageDraw.Draw(self.im)

    def rect(self, box, color, outline=None, width=1):
        self.d.rectangle(tuple(int(v) for v in box), fill=color,
                         outline=outline, width=width)

    def poly(self, points, color, outline=None, width=1):
        pts = [(int(x), int(y)) for x, y in points]
        self.d.polygon(pts, fill=color)
        if outline:
            self.d.line(pts + [pts[0]], fill=outline, width=width)

    def line(self, points, color, width=1):
        self.d.line([(int(x), int(y)) for x, y in points], fill=color, width=width)

    def ellipse(self, box, color, outline=None, width=1):
        self.d.ellipse(tuple(int(v) for v in box), fill=color,
                       outline=outline, width=width)

    def save(self, name):
        save_indexed(self.im, OUT / name)


# Muted Silent-Hill palette: cool fog light, olive cloth, dirty metal, rust accents.
HAIR = (43, 36, 32, 255)
HAIR_HI = (76, 61, 48, 255)
SKIN = (184, 148, 121, 255)
SKIN_HI = (216, 178, 143, 255)
SKIN_SHADE = (123, 91, 76, 255)
COAT = (66, 78, 65, 255)
COAT_HI = (101, 111, 87, 255)
COAT_SHADE = (43, 53, 47, 255)
PANTS = (43, 47, 50, 255)
PANTS_HI = (66, 68, 66, 255)
BOOT = (27, 27, 28, 255)
BOOT_HI = (75, 68, 57, 255)
METAL = (96, 103, 103, 255)
METAL_HI = (177, 179, 162, 255)
RUST = (137, 65, 43, 255)


def hero(view, frame):
    p = P(28, 38)
    step = (-2, -1, 2, 1)[frame]
    swing = (-1, 1, 1, -1)[frame]

    # Legs/boots first, with a strong alternating step silhouette.
    if view == 's':
        p.poly([(11, 24), (16, 23), (17+step, 31), (14+step, 34),
                (10, 31)], PANTS, INK)
        p.poly([(12, 25), (14, 25), (14+step, 30), (12, 30)], PANTS_HI)
        p.poly([(16, 23), (21, 24), (21-step, 31), (18-step, 34),
                (14, 31)], PANTS, INK)
        p.poly([(9+step, 31), (15+step, 31), (17+step, 35),
                (8+step, 35)], BOOT, INK)
        p.poly([(15-step, 31), (20-step, 31), (22-step, 35),
                (13-step, 35)], BOOT, INK)
        p.line([(9+step, 34), (16+step, 34)], BOOT_HI, 1)
        p.line([(14-step, 34), (21-step, 34)], BOOT_HI, 1)
    else:
        lx, rx = 7 + step//2, 16 - step//2
        p.poly([(lx, 24), (lx+5, 24), (lx+5, 32), (lx+1, 34),
                (lx-1, 30)], PANTS, INK)
        p.poly([(lx+2, 26), (lx+4, 26), (lx+3, 31), (lx+1, 31)], PANTS_HI)
        p.poly([(rx, 24), (rx+5, 24), (rx+6, 31), (rx+3, 34),
                (rx, 31)], PANTS, INK)
        p.line([(rx+2, 26), (rx+3, 30)], COAT_SHADE, 1)
        p.poly([(lx-2, 32), (lx+4, 32), (lx+6, 36), (lx-3, 36)], BOOT, INK)
        p.poly([(rx-1, 32), (rx+5, 32), (rx+7, 36), (rx-1, 36)], BOOT, INK)
        p.line([(lx-1, 35), (lx+5, 35)], BOOT_HI, 1)
        p.line([(rx, 35), (rx+6, 35)], BOOT_HI, 1)

    # Far arm swings behind the jacket.
    if view == 's':
        p.poly([(8, 15), (12, 15), (12+swing, 23), (9+swing, 26),
                (6, 21)], COAT_SHADE, INK)
        p.poly([(8+swing, 22), (11+swing, 23), (10+swing, 27),
                (7+swing, 26)], SKIN_SHADE, INK)
        p.rect((8+swing, 23, 10+swing, 25), SKIN)
        p.poly([(11, 14), (14, 12), (21, 14), (23, 17), (22, 25),
                (19, 27), (11, 26), (9, 22)], COAT, INK)
        p.poly([(15, 15), (20, 15), (21, 21), (18, 24),
                (15, 23)], COAT_HI)
        p.poly([(10, 17), (13, 15), (14, 22), (12, 24), (10, 21)], COAT_SHADE)
        p.line([(14, 18), (18, 18), (19, 21)], (128, 119, 92, 255), 1)
        p.line([(12, 16), (16, 15), (20, 16)], COAT_HI, 1)
        p.rect((17, 17, 18, 18), (135, 124, 94, 255))
        p.rect((12, 20, 13, 21), COAT_SHADE)
        p.line([(14, 23), (18, 22)], (120, 111, 87, 255), 1)
        p.rect((13, 25, 18, 27), PANTS, INK)
        p.line([(14, 27), (17, 27)], PANTS_HI, 1)
        # Profile: tired face, nose and swept dark hair.
        p.ellipse((13, 2, 22, 14), HAIR, INK)
        p.poly([(15, 5), (20, 5), (22, 9), (25, 10), (22, 13),
                (17, 14), (13, 11)], SKIN, INK)
        p.poly([(13, 5), (15, 2), (21, 3), (23, 6), (21, 8),
                (18, 6), (15, 8)], HAIR, INK)
        p.line([(18, 8), (20, 8)], HAIR, 1)
        p.rect((23, 10, 24, 10), SKIN_HI)
        p.line([(16, 11), (20, 12)], SKIN_SHADE, 1)
        p.rect((14, 11, 16, 12), SKIN_SHADE)
    else:
        armshift = 2 - swing
        p.poly([(5, 15), (9, 15), (9+swing, 23), (7+swing, 26),
                (4, 21)], COAT_SHADE, INK)
        p.poly([(4+swing, 22), (8+swing, 23), (7+swing, 27),
                (4+swing, 26)], SKIN_SHADE, INK)
        p.rect((5+swing, 23, 7+swing, 25), SKIN)
        # Jacket torso with shoulder yoke, zipper, seams and compact pockets.
        p.poly([(8, 14), (11, 12), (18, 12), (22, 15), (21, 26),
                (18, 28), (8, 27), (6, 23), (6, 17)], COAT, INK)
        p.poly([(9, 16), (12, 14), (13, 25), (9, 26), (7, 22)], COAT_HI)
        p.poly([(15, 14), (19, 14), (20, 21), (18, 25),
                (15, 23)], COAT_SHADE)
        p.line([(12, 16), (13, 24)], (134, 125, 96, 255), 1)
        p.line([(13, 17), (19, 14)], (124, 114, 86, 255), 1)
        p.rect((8, 19, 11, 22), COAT_SHADE, INK)
        p.rect((16, 19, 19, 22), COAT_SHADE, INK)
        p.line([(8, 19), (11, 19)], COAT_HI, 1)
        p.line([(16, 19), (19, 19)], COAT_HI, 1)
        # Small material cues: raised collar, stitch marks, zipper pull and sleeve folds.
        p.line([(9, 14), (11, 13), (13, 14)], COAT_HI, 1)
        p.line([(14, 15), (14, 23)], (150, 140, 108, 255), 1)
        p.rect((15, 19, 15, 19), (205, 176, 111, 255))
        p.line([(7, 20), (8, 22)], (135, 125, 96, 255), 1)
        p.line([(19, 23), (20, 21)], (132, 122, 92, 255), 1)
        p.rect((10, 16, 11, 16), (169, 157, 119, 255))
        p.rect((18, 16, 18, 16), COAT_HI)
        p.rect((9, 24, 18, 26), PANTS, INK)
        p.rect((13, 24, 15, 25), (141, 124, 88, 255), INK)
        p.rect((12, 9, 16, 14), SKIN_SHADE)
        p.rect((13, 10, 16, 13), SKIN)
        p.ellipse((9, 2, 19, 13), HAIR, INK)
        if view == 'd':
            p.poly([(9, 5), (11, 2), (18, 2), (21, 5), (20, 8),
                    (17, 6), (14, 8), (11, 6), (10, 9)], HAIR, INK)
            p.poly([(10, 6), (18, 6), (20, 9), (18, 13),
                    (12, 13), (9, 10)], SKIN, INK)
            p.rect((11, 8, 12, 8), (38, 32, 29, 255))
            p.rect((16, 8, 17, 8), (38, 32, 29, 255))
            p.rect((13, 9, 13, 10), SKIN_SHADE)
            p.line([(12, 11), (16, 11)], SKIN_SHADE, 1)
            p.rect((9, 8, 10, 10), SKIN_SHADE)
            p.rect((19, 8, 20, 10), SKIN_SHADE)
            # Facial planes and tired eyes: deliberately small, readable clusters.
            p.rect((10, 7, 12, 7), HAIR_HI)
            p.rect((16, 7, 18, 7), HAIR_HI)
            p.rect((11, 8, 11, 8), (226, 201, 168, 255))
            p.rect((16, 8, 16, 8), (226, 201, 168, 255))
            p.rect((10, 9, 10, 10), (157, 112, 91, 255))
            p.rect((18, 9, 18, 10), (157, 112, 91, 255))
            p.rect((15, 10, 16, 10), SKIN_HI)
            p.poly([(10, 6), (12, 4), (14, 6), (16, 4), (20, 6),
                    (19, 7), (11, 7)], HAIR)
        else:
            p.poly([(9, 4), (11, 2), (18, 2), (21, 5), (20, 11),
                    (17, 14), (10, 12), (9, 7)], HAIR, INK)
            p.poly([(11, 4), (17, 3), (19, 5), (15, 6), (11, 7)], HAIR_HI)
            p.line([(10, 8), (11, 11), (14, 12)], HAIR_HI, 1)
        # Back/side folds and a subdued satchel strap, with stitch-sized highlights.
        p.line([(18, 15), (15, 23)], (120, 111, 85, 255), 1)
        p.line([(8, 16), (11, 14), (14, 14)], COAT_HI, 1)
        p.line([(7, 22), (9, 24)], (119, 116, 93, 255), 1)
        p.line([(18, 24), (20, 22)], (112, 109, 87, 255), 1)
        p.rect((18, 18, 19, 21), (40, 48, 43, 255))
        p.rect((17, 20, 18, 20), (157, 142, 105, 255))

    p.save(f'hero_{view}{frame}.png')


def hollow(frame):
    p = P(28, 38)
    sway = (-2, -1, 2, 1)[frame]
    robe = (77, 74, 67, 255); robe_hi = (106, 99, 85, 255)
    skin = (135, 130, 118, 255)
    # Slumped coat and narrow legs.
    p.poly([(8, 14), (18, 13), (22, 18), (21, 29), (18, 34),
            (9, 33), (6, 28), (5, 20)], robe, INK)
    p.poly([(9, 17), (13, 16), (13, 29), (9, 31), (7, 25)], robe_hi)
    p.line([(15, 16), (14, 29)], (43, 42, 39, 255), 1)
    p.line([(10, 18), (12, 17), (13, 18)], (137, 126, 105, 255), 1)
    p.rect((16, 19, 18, 22), (62, 58, 51, 255))
    p.rect((17, 19, 17, 19), (164, 143, 110, 255))
    p.line([(11, 24), (13, 26)], (61, 56, 51, 255), 1)
    p.poly([(9, 28), (13, 29), (16, 28), (17, 30), (13, 31), (9, 30)],
           (49, 47, 44, 255))
    # Uneven sleeves swing from the shoulders; pale fingers hang below.
    p.poly([(6, 17), (10, 17), (9+sway, 27), (7+sway, 31),
            (4+sway, 28)], (65, 63, 59, 255), INK)
    p.poly([(18, 17), (22, 17), (24-sway, 26), (22-sway, 31),
            (19-sway, 28)], (65, 63, 59, 255), INK)
    p.rect((5+sway, 28, 8+sway, 33), skin, INK)
    p.rect((20-sway, 28, 23-sway, 33), skin, INK)
    p.line([(7+sway, 30), (7+sway, 33)], (92, 87, 79, 255), 1)
    p.line([(21-sway, 30), (21-sway, 33)], (92, 87, 79, 255), 1)
    p.poly([(9, 30), (13, 30), (13+sway, 36), (9+sway, 36)], robe, INK)
    p.poly([(15, 30), (19, 30), (19-sway, 36), (15-sway, 36)], robe, INK)
    p.ellipse((8, 2, 19, 16), (52, 50, 45, 255), INK)
    p.poly([(9, 7), (17, 5), (20, 9), (17, 15), (11, 15), (8, 11)], skin, INK)
    p.poly([(8, 5), (11, 2), (18, 3), (20, 7), (17, 8),
            (13, 6), (9, 9)], (67, 64, 58, 255), INK)
    p.rect((10, 9, 11, 10), (31, 25, 23, 255))
    p.rect((16, 9, 17, 10), (31, 25, 23, 255))
    p.rect((10, 9, 10, 9), (179, 50, 38, 255))
    p.rect((16, 9, 16, 9), (179, 50, 38, 255))
    p.line([(12, 13), (16, 12)], (75, 62, 55, 255), 1)
    # Two intentional rips, not speckled noise.
    p.poly([(8, 27), (11, 29), (10, 32), (7, 31)], (126, 48, 38, 255))
    p.save(f'hollow{frame}.png')


def hound(frame):
    p = P(38, 24)
    stride = (-3, 1, 3, -1)[frame]
    fur = (65, 50, 48, 255); fur_hi = (102, 77, 68, 255)
    # Tail and rear legs behind a low, ribbed body.
    p.line([(8, 11), (4, 7+(frame&1)), (1, 7)], fur, 2)
    p.poly([(7, 8), (16, 5), (26, 7), (30, 12), (27, 17),
            (16, 18), (7, 14)], fur, INK)
    p.poly([(10, 9), (17, 7), (24, 9), (26, 13), (18, 16), (10, 14)], fur_hi)
    p.line([(12, 9), (14, 14)], (53, 41, 40, 255), 1)
    p.line([(17, 8), (19, 14)], (53, 41, 40, 255), 1)
    p.line([(22, 9), (23, 13)], (53, 41, 40, 255), 1)
    p.poly([(10, 9), (13, 8), (15, 9), (13, 11), (10, 11)],
           (128, 93, 78, 255))
    p.rect((18, 10, 19, 11), (141, 99, 80, 255))
    p.line([(13, 15), (17, 16), (20, 15)], (119, 86, 75, 255), 1)
    # Four articulated legs, moving in opposite phases.
    for i, x in enumerate((9, 14, 23, 28)):
        q = stride if i in (0, 3) else -stride
        p.poly([(x, 13), (x+3, 13), (x+2+q, 19), (x-1+q, 21)], fur, INK)
        p.line([(x-1+q, 20), (x+3+q, 20)], INK, 1)
    p.poly([(24, 7), (30, 4), (35, 6), (37, 10), (34, 13),
            (30, 12), (28, 10)], fur, INK)
    p.poly([(30, 7), (34, 7), (37, 10), (33, 11), (29, 10)],
           (129, 97, 81, 255))
    p.rect((32, 7, 33, 8), (217, 53, 39, 255))
    p.poly([(34, 10), (38, 10), (37, 13), (33, 13)], (38, 29, 29, 255), INK)
    p.line([(6, 10), (3, 8)], fur_hi, 1)
    p.save(f'hound{frame}.png')


def flyer(frame):
    p = P(32, 26)
    body = (57, 42, 44, 255); wing = (75, 54, 55, 255)
    membrane = (104, 74, 72, 255)
    shapes = [
        [(15, 11), (2, 2), (4, 13), (1, 19), (9, 17), (15, 15)],
        [(15, 11), (2, 7), (4, 16), (10, 15), (15, 15)],
        [(15, 11), (3, 16), (6, 22), (13, 17)],
        [(15, 11), (4, 11), (5, 18), (12, 16)],
    ]
    shape = shapes[frame]
    p.poly(shape, wing, INK)
    p.poly([(31-x, y) for x, y in shape], wing, INK)
    # Three clean membrane ribs per wing, like hand-placed pixel clusters.
    if frame in (0, 2):
        for end in ((4, 14), (8, 15), (12, 15)):
            p.line([(15, 12), end], membrane, 1)
            p.line([(16, 12), (31-end[0], end[1])], membrane, 1)
    p.poly([(12, 7), (15, 5), (19, 6), (21, 10), (19, 17),
            (15, 18), (11, 14)], body, INK)
    p.ellipse((11, 2, 20, 11), (68, 51, 49, 255), INK)
    p.poly([(13, 4), (19, 4), (20, 7), (17, 10), (12, 9)],
           (126, 99, 87, 255), INK)
    p.rect((13, 6, 14, 7), (220, 51, 38, 255))
    p.rect((18, 6, 19, 7), (220, 51, 38, 255))
    p.line([(13, 16), (10, 22)], INK, 1)
    p.line([(18, 16), (21, 22)], INK, 1)
    p.save(f'flyer{frame}.png')


def boss(frame):
    p = P(50, 58)
    sway = (-2, -1, 2, 1)[frame]
    body = (43, 35, 34, 255); mid = (75, 57, 52, 255)
    p.poly([(18, 12), (33, 11), (42, 20), (40, 39), (46, 52),
            (34, 54), (26, 48), (15, 55), (7, 51), (13, 37),
            (10, 21)], body, INK)
    p.poly([(20, 15), (32, 14), (37, 23), (35, 39),
            (28, 46), (18, 40), (16, 23)], mid)
    # Three radio mouths, wire crown and cable arms.
    for x, y in ((21+sway, 22), (34+sway, 24), (28-sway, 38)):
        p.ellipse((x-5, y-5, x+5, y+5), (28, 25, 25, 255), INK)
        p.ellipse((x-3, y-3, x+3, y+3), (86, 62, 57, 255))
        p.rect((x, y, x+1, y+1), (205, 47, 37, 255))
    p.line([(15, 20), (7+sway, 30), (11, 38)], (111, 78, 66, 255), 2)
    p.line([(39, 20), (46-sway, 29), (42, 38)], (111, 78, 66, 255), 2)
    p.line([(19, 47), (15, 56)], INK, 2)
    p.line([(35, 47), (39, 56)], INK, 2)
    p.line([(19, 13), (15, 5), (11, 3)], (91, 75, 66, 255), 1)
    p.line([(26, 12), (25, 2)], (91, 75, 66, 255), 1)
    p.line([(34, 13), (39, 5), (43, 4)], (91, 75, 66, 255), 1)
    p.save(f'boss{frame}.png')


def car(rust=False):
    p = P(72, 52)
    body = (73, 91, 96, 255) if not rust else (92, 54, 40, 255)
    body_hi = (113, 128, 128, 255) if not rust else (126, 76, 50, 255)
    side_l = (48, 63, 68, 255) if not rust else (63, 39, 31, 255)
    side_r = (35, 47, 52, 255) if not rust else (47, 31, 27, 255)
    glass = (27, 48, 57, 255); glass_hi = (108, 135, 137, 255)
    # Two side planes and low steel body.
    p.poly([(4, 24), (35, 41), (35, 49), (4, 32)], side_l, INK)
    p.poly([(35, 41), (68, 23), (68, 32), (35, 49)], side_r, INK)
    p.poly([(4, 24), (35, 6), (68, 23), (35, 42)], body, INK)
    p.line([(7, 25), (33, 40)], body_hi, 1)
    p.line([(37, 40), (65, 24)], (84, 94, 94, 255), 1)
    # Raised cabin and legible windows on both visible sides.
    p.poly([(14, 22), (35, 10), (55, 21), (35, 33)], body_hi, INK)
    p.poly([(16, 22), (35, 31), (35, 39), (16, 29)], side_l, INK)
    p.poly([(35, 31), (53, 21), (53, 29), (35, 39)], side_r, INK)
    p.poly([(18, 22), (25, 18), (32, 22), (25, 27)], glass, INK)
    p.poly([(38, 30), (47, 25), (47, 30), (38, 35)], glass, INK)
    # Split rear glass and front windscreen on the roof plane; the large hood
    # remains a different metal value so the tiny vehicle reads as a sedan.
    p.poly([(26, 19), (33, 15), (38, 18), (31, 22)], glass, INK)
    p.poly([(38, 20), (45, 16), (51, 20), (44, 24)], glass, INK)
    p.poly([(47, 24), (58, 21), (64, 23), (52, 30)], (84, 103, 106, 255))
    p.line([(19, 22), (24, 19)], glass_hi, 1)
    p.line([(39, 30), (45, 26)], glass_hi, 1)
    p.line([(28, 19), (32, 16)], glass_hi, 1)
    p.line([(40, 20), (44, 17)], glass_hi, 1)
    p.line([(7, 25), (18, 31), (25, 27)], (146, 145, 128, 255), 1)
    # Body seams, door handles and a hood highlight make the silhouette read as a sedan.
    p.line([(9, 29), (21, 35), (28, 31)], (74, 86, 87, 255), 1)
    p.line([(39, 38), (50, 32), (58, 28)], (85, 95, 91, 255), 1)
    p.rect((20, 33, 22, 33), (180, 166, 126, 255), INK)
    p.rect((46, 34, 48, 34), (158, 153, 126, 255), INK)
    p.line([(44, 22), (52, 23), (59, 23)], (129, 137, 126, 255), 1)
    p.line([(45, 24), (50, 26)], (62, 75, 76, 255), 1)
    # Headlamps, red tail lamps, grille and bumpers.
    p.rect((65, 22, 68, 25), (243, 214, 140, 255), INK)
    p.rect((64, 25, 67, 27), (232, 192, 115, 255), INK)
    p.rect((4, 24, 7, 26), (190, 49, 37, 255), INK)
    p.line([(61, 33), (68, 29)], (166, 157, 137, 255), 2)
    p.line([(63, 26), (68, 23)], (26, 30, 31, 255), 2)
    p.line([(48, 32), (52, 30)], INK, 1)
    # Four exposed wheels with small hubs, layered over the lower body.
    for x, y in ((13, 34), (29, 43), (53, 34), (39, 43)):
        p.ellipse((x-4, y-4, x+4, y+5), (14, 15, 16, 255), INK)
        p.ellipse((x-2, y-2, x+2, y+2), (101, 103, 96, 255), INK)
        p.rect((x, y-1, x, y+1), (51, 54, 53, 255))
    if rust:
        p.poly([(17, 25), (20, 26), (18, 29), (16, 28)], (173, 80, 44, 255))
        p.rect((48, 27, 50, 28), (170, 76, 40, 255))
        p.line([(30, 38), (34, 40)], (144, 67, 39, 255), 1)
    p.save('car_rust.png' if rust else 'car.png')


def bus(rust=False):
    p = P(88, 64)
    body = (132, 119, 68, 255) if not rust else (91, 54, 38, 255)
    body_hi = (163, 146, 81, 255) if not rust else (122, 70, 44, 255)
    side_l = (86, 78, 51, 255) if not rust else (61, 39, 30, 255)
    side_r = (64, 59, 43, 255) if not rust else (48, 32, 27, 255)
    glass = (27, 49, 58, 255); glass_hi = (102, 131, 134, 255)
    p.poly([(4, 23), (45, 44), (45, 61), (4, 37)], side_l, INK)
    p.poly([(45, 44), (84, 21), (84, 38), (45, 61)], side_r, INK)
    p.poly([(4, 23), (45, 1), (84, 21), (45, 45)], body, INK)
    p.poly([(11, 23), (45, 5), (77, 22), (45, 40)], body_hi, INK)
    p.poly([(35, 12), (45, 7), (54, 12), (45, 18)], (104, 99, 69, 255), INK)
    p.line([(7, 33), (45, 57), (82, 34)], (190, 166, 100, 255), 2)
    # Passenger windows run along both long sides; pillars remain broad/readable.
    leftwins=[[(8,26),(17,31),(17,39),(8,34)],
              [(20,32),(29,37),(29,45),(20,40)],
              [(32,38),(41,43),(41,51),(32,46)]]
    rightwins=[[(49,44),(58,39),(58,47),(49,52)],
               [(61,37),(70,32),(70,40),(61,45)],
               [(73,30),(81,25),(81,33),(73,38)]]
    for pts in leftwins+rightwins:
        p.poly(pts, glass, INK)
        p.line([pts[0],pts[1]],glass_hi,1)
    # Roof vents, a roof hatch and passenger door distinguish the bus from a box.
    p.poly([(20,18),(31,12),(40,17),(29,23)], (86, 83, 63, 255), INK)
    p.line([(23,18),(31,14),(37,17)], (148, 136, 88, 255), 1)
    p.line([(24,20),(32,16),(38,19)], (49, 50, 43, 255), 1)
    p.poly([(61,45),(70,40),(70,52),(61,57)], side_r, INK)
    p.line([(62,47),(62,56)], body_hi, 1)
    p.rect((67,47,68,49), (197, 170, 104, 255), INK)
    p.line([(61,57),(71,52)], (163, 151, 115, 255), 2)
    # Front windshield, destination plaque, bumper and signal lamps.
    p.poly([(73,20),(81,16),(83,20),(75,25)], glass, INK)
    p.line([(75,20),(80,18)], glass_hi, 1)
    p.rect((74, 12, 82, 15), (99, 89, 57, 255), INK)
    p.line([(75,13),(81,13)], (207, 187, 119, 255), 1)
    p.rect((81, 25, 84, 28), (240, 214, 142, 255), INK)
    p.rect((5, 31, 8, 33), (189, 50, 38, 255), INK)
    p.line([(5, 37), (45, 60), (83, 37)], (163, 153, 119, 255), 2)
    # Wheels/hubs are drawn last so they stay visible at small scale.
    for x, y in ((12, 38), (31, 51), (58, 51), (77, 36)):
        p.ellipse((x-4, y-4, x+4, y+5), (14, 15, 16, 255), INK)
        p.ellipse((x-2, y-2, x+2, y+2), (94, 94, 83, 255), INK)
    if rust:
        p.poly([(22,30),(25,31),(23,34),(20,33)], (171,78,43,255))
        p.rect((53,45,55,46),(161,71,39,255))
        p.line([(68,39),(72,37)],(157,69,39,255),2)
    p.save('bus_rust.png' if rust else 'bus.png')


def nina():
    p=P(28,38)
    p.poly([(8,25),(13,25),(14,32),(10,34),(7,31)], PANTS, INK)
    p.poly([(15,25),(20,25),(21,32),(18,34),(14,31)], PANTS, INK)
    p.poly([(7,31),(13,31),(14,36),(6,36)], BOOT, INK)
    p.poly([(14,31),(20,31),(22,36),(14,36)], BOOT, INK)
    p.poly([(7,14),(10,12),(18,12),(22,16),(21,27),(18,29),
            (8,28),(5,22)], (104,47,45,255), INK)
    p.poly([(9,16),(13,14),(14,26),(9,26)], (148,67,59,255))
    p.line([(14,15),(17,26)], (61,38,37,255), 1)
    p.poly([(5,16),(9,15),(9,23),(7,26),(4,22)], (59,55,51,255), INK)
    p.rect((4,22,7,26), SKIN, INK)
    p.rect((12,10,16,14), SKIN_SHADE)
    p.ellipse((9,2,20,14),(78,40,32,255),INK)
    p.poly([(10,6),(19,5),(21,9),(18,14),(11,13),(8,10)],(205,154,123,255),INK)
    p.poly([(8,6),(10,2),(18,2),(21,5),(19,8),(16,6),(12,8),(10,10)],
           (112,43,31,255),INK)
    p.rect((11,8,12,8), INK); p.rect((17,8,18,8), INK)
    p.line([(12,11),(17,11)],(105,63,50,255),1)
    p.save('nina.png')


def tree():
    p=P(36,56)
    p.poly([(16,31),(21,30),(23,52),(13,52)],(58,43,33,255),INK)
    p.poly([(16,39),(8,45),(6,49),(12,48),(18,43)],(68,48,36,255),INK)
    p.poly([(20,38),(29,44),(31,48),(25,49),(18,43)],(63,46,35,255),INK)
    tiers=[[(18,2),(3,27),(33,26)],[(18,11),(1,36),(34,35)],[(18,20),(4,45),(32,44)]]
    for i,pts in enumerate(tiers):
        p.poly(pts,(34+i*2,55+i*2,43+i,255),INK)
        p.poly([(18,pts[0][1]+4),(9,pts[1][1]-2),(25,pts[2][1]-3)],
               (53+i*2,72+i*2,49+i,255))
    for x,y in ((10,25),(24,19),(8,35),(27,32),(14,42)):
        p.rect((x,y,x+1,y+1),(121,116,76,255))
    p.save('tree.png')


def lamp():
    p=P(20,54)
    p.rect((9,18,12,50),(38,40,40,255),INK)
    p.rect((10,21,10,47),(112,111,99,255))
    p.line([(10,20),(6,15),(6,11)],(41,43,43,255),2)
    p.rect((3,7,11,15),(53,57,54,255),INK)
    p.rect((4,8,10,14),(119,123,111,255))
    p.rect((5,9,9,13),(205,180,119,255),INK)
    p.rect((6,10,8,12),(226,207,150,255))
    p.poly([(3,7),(7,3),(12,7)],(44,47,46,255),INK)
    p.rect((7,15,13,18),(37,39,38,255),INK)
    p.line([(10,25),(11,42)],(141,136,116,255),1)
    p.save('lamp.png')


def bell():
    # Compact, readable hanging church bell with no painted ground shadow.
    p=P(24,36)
    p.poly([(2,3),(12,1),(22,3),(22,6),(2,6)],(58,49,38,255),INK)
    p.line([(4,4),(20,4)],(132,104,66,255),1)
    p.line([(5,6),(5,13)],(43,40,34,255),2)
    p.line([(19,6),(19,13)],(43,40,34,255),2)
    p.line([(6,11),(18,11)],(116,89,57,255),2)
    p.ellipse((9,11,15,14),(91,69,45,255),INK)
    p.poly([(9,14),(15,14),(18,22),(17,27),(7,27),(6,22)],(116,91,57,255),INK)
    p.poly([(10,15),(14,15),(16,22),(15,24),(9,24),(8,21)],(165,133,81,255))
    p.line([(8,25),(16,25)],(57,47,35,255),1)
    p.ellipse((10,26,14,29),(82,63,43,255),INK)
    p.line([(12,29),(12,34)],(63,49,36,255),1)
    p.rect((10,34,14,35),(110,72,43,255),INK)
    p.save('bell.png')


def kiosk():
    p=P(50,46)
    p.poly([(4,17),(25,5),(46,17),(25,29)],(92,69,49,255),INK)
    p.poly([(4,17),(25,29),(25,42),(4,30)],(71,60,49,255),INK)
    p.poly([(25,29),(46,17),(46,30),(25,42)],(51,46,42,255),INK)
    # Awning, front service window, wooden counter and a small sign.
    p.poly([(5,17),(25,27),(25,32),(5,22)],(127,75,52,255),INK)
    p.poly([(25,27),(45,17),(45,22),(25,32)],(91,58,43,255),INK)
    p.poly([(7,22),(20,29),(20,37),(7,30)],(27,49,57,255),INK)
    p.poly([(29,30),(43,22),(43,31),(29,38)],(26,43,49,255),INK)
    p.line([(8,23),(18,29)],(111,139,140,255),1)
    p.line([(31,30),(40,25)],(104,130,133,255),1)
    p.line([(6,31),(24,41)],(127,96,62,255),2)
    p.line([(26,41),(44,31)],(90,68,48,255),2)
    p.poly([(13,12),(25,5),(37,12),(25,19)],(56,57,53,255),INK)
    p.rect((16,10,34,14),(116,82,51,255),INK)
    p.line([(18,11),(31,11)],(197,157,96,255),1)
    for x in (11,17,23,29,35):
        p.line([(x,19),(x,22)],(188,134,81,255) if x%2 else (74,47,39,255),2)
    p.save('kiosk.png')


def phonebooth():
    p=P(34,50)
    p.poly([(4,12),(17,5),(30,12),(17,20)],(72,79,74,255),INK)
    p.poly([(4,12),(17,20),(17,46),(4,38)],(47,59,56,255),INK)
    p.poly([(17,20),(30,12),(30,38),(17,46)],(35,43,43,255),INK)
    p.poly([(7,16),(14,20),(14,41),(7,36)],(25,47,55,255),INK)
    p.poly([(19,21),(27,17),(27,38),(19,42)],(24,41,48,255),INK)
    p.line([(8,17),(13,20)],(117,143,145,255),1)
    p.line([(20,22),(26,19)],(99,125,127,255),1)
    p.rect((5,9,29,13),(132,45,36,255),INK)
    p.line([(8,10),(26,10)],(205,159,96,255),1)
    # Receiver silhouette and old coin box on the right glass pane.
    p.line([(23,26),(25,26),(26,30),(24,32)],(199,177,128,255),2)
    p.rect((22,33,26,37),(116,103,79,255),INK)
    p.rect((23,34,24,34),(215,186,121,255))
    p.save('phonebooth.png')


def console():
    p=P(44,46)
    p.poly([(4,22),(24,10),(40,20),(20,32)],(75,80,77,255),INK)
    p.poly([(4,22),(20,32),(20,42),(4,32)],(45,50,50,255),INK)
    p.poly([(20,32),(40,20),(40,31),(20,42)],(31,36,38,255),INK)
    p.poly([(8,21),(24,12),(35,19),(20,28)],(57,64,62,255),INK)
    p.poly([(11,20),(20,15),(25,18),(16,23)],(17,36,41,255),INK)
    p.line([(12,20),(19,16)],(113,153,143,255),1)
    p.line([(14,21),(19,18),(21,19),(16,23)],(107,205,152,255),1)
    p.poly([(23,27),(36,20),(36,31),(23,38)],(41,47,48,255),INK)
    p.rect((25,28,31,32),(111,99,72,255),INK)
    p.line([(26,29),(30,29)],(203,171,105,255),1)
    p.rect((32,32,34,34),(119,48,37,255),INK)
    p.line([(7,30),(17,36)],(128,116,84,255),1)
    p.save('console.png')


def speaker():
    p=P(30,36)
    p.poly([(5,10),(18,3),(26,8),(13,16)],(75,78,73,255),INK)
    p.poly([(5,10),(13,16),(13,33),(5,27)],(47,52,51,255),INK)
    p.poly([(13,16),(26,8),(26,27),(13,33)],(32,37,38,255),INK)
    p.poly([(17,18),(23,14),(23,24),(17,28)],(18,23,24,255),INK)
    p.line([(18,19),(22,16)],(128,124,105,255),1)
    p.ellipse((7,25,11,29),(151,48,37,255),INK)
    p.save('speaker.png')


def control_panel():
    p=P(30,38)
    p.poly([(5,10),(19,3),(26,7),(12,15)],(84,88,80,255),INK)
    p.poly([(5,10),(12,15),(12,34),(5,29)],(50,56,54,255),INK)
    p.poly([(12,15),(26,7),(26,27),(12,34)],(34,40,40,255),INK)
    p.poly([(15,18),(23,13),(23,21),(15,26)],(19,31,34,255),INK)
    p.line([(16,22),(22,17)],(175,189,154,255),1)
    p.rect((15,28,17,30),(195,53,40,255),INK)
    p.rect((20,26,22,28),(72,149,91,255),INK)
    p.rect((15,32,21,33),(109,95,72,255),INK)
    p.save('control_panel.png')


def bookshelf():
    p=P(40,48)
    p.poly([(4,9),(21,1),(36,9),(19,19)],(91,64,42,255),INK)
    p.poly([(4,9),(19,19),(19,43),(4,34)],(55,43,33,255),INK)
    p.poly([(19,19),(36,9),(36,34),(19,43)],(39,34,30,255),INK)
    for y in (22,30,38):
        p.line([(5,y-1),(19,y+7),(35,y-2)],(133,96,61,255),2)
        p.line([(6,y),(19,y+7),(34,y-1)],(39,31,27,255),1)
        for x,c in ((8,(107,48,40,255)),(12,(49,61,64,255)),
                    (16,(118,85,50,255)),(22,(49,69,55,255)),
                    (27,(102,55,44,255)),(31,(76,77,73,255))):
            h=4+(x%3)
            p.rect((x,y-h,x+2,y),c,INK)
            p.line([(x,y-h+1),(x+1,y-h+1)],(187,157,104,255),1)
    p.save('bookshelf.png')


def counter():
    p=P(40,34)
    p.poly([(3,16),(21,6),(37,15),(18,26)],(123,86,51,255),INK)
    p.poly([(3,16),(18,26),(18,31),(3,21)],(78,53,37,255),INK)
    p.poly([(18,26),(37,15),(37,21),(18,31)],(54,40,31,255),INK)
    p.line([(5,16),(18,25),(35,15)],(181,133,75,255),2)
    p.poly([(6,22),(17,28),(17,31),(6,25)],(96,62,39,255),INK)
    p.poly([(22,27),(33,20),(33,24),(22,30)],(70,48,34,255),INK)
    p.rect((10,23,13,24),(185,143,84,255),INK)
    p.rect((27,24,30,25),(176,132,77,255),INK)
    p.save('counter.png')


def pew():
    p=P(40,30)
    p.poly([(6,8),(21,1),(35,9),(19,18)],(88,54,37,255),INK)
    p.poly([(6,8),(19,18),(19,21),(6,12)],(54,38,30,255),INK)
    p.poly([(19,18),(35,9),(35,13),(19,22)],(40,31,27,255),INK)
    p.line([(8,9),(20,17),(33,9)],(151,99,60,255),2)
    p.poly([(3,20),(20,11),(37,20),(20,29)],(118,77,47,255),INK)
    p.line([(5,20),(20,28),(35,20)],(179,127,70,255),1)
    p.poly([(7,21),(12,24),(12,28),(7,26)],(68,47,35,255),INK)
    p.poly([(29,21),(34,18),(34,26),(30,28)],(48,37,30,255),INK)
    p.save('pew.png')


def altar():
    p=P(44,40)
    p.poly([(8,21),(24,12),(40,21),(22,31)],(143,134,115,255),INK)
    p.poly([(8,21),(22,31),(22,37),(8,27)],(80,77,69,255),INK)
    p.poly([(22,31),(40,21),(40,27),(22,37)],(58,58,54,255),INK)
    p.poly([(5,17),(24,7),(42,17),(22,28)],(184,171,145,255),INK)
    p.line([(6,17),(22,28),(41,17)],(221,207,174,255),1)
    p.poly([(18,22),(24,26),(24,35),(19,32)],(108,35,34,255),INK)
    p.rect((12,14,14,20),(214,205,171,255),INK)
    p.rect((12,12,14,13),(232,176,78,255))
    p.line([(31,10),(31,19)],(108,70,38,255),2)
    p.line([(28,13),(34,13)],(108,70,38,255),2)
    p.save('altar.png')


def vending():
    p=P(34,42)
    p.poly([(4,11),(20,2),(31,8),(15,18)],(98,103,94,255),INK)
    p.poly([(4,11),(15,18),(15,38),(4,31)],(55,61,58,255),INK)
    p.poly([(15,18),(31,8),(31,30),(15,38)],(38,44,44,255),INK)
    p.poly([(7,14),(13,18),(13,29),(7,25)],(27,50,58,255),INK)
    p.line([(8,15),(12,18)],(123,148,149,255),1)
    p.rect((18,22,28,29),(70,77,70,255),INK)
    p.line([(19,24),(27,24)],(146,134,101,255),1)
    p.rect((20,31,26,35),(107,86,59,255),INK)
    p.rect((24,32,25,34),(204,174,115,255))
    p.rect((17,33,19,35),(54,61,56,255),INK)
    p.save('vending.png')


if __name__ == '__main__':
    # Character bases come from the user's sprite archive and are built by
    # generate_characters.py. This script makes only editable world props.
    car(False); car(True); bus(False); bus(True)
    tree(); lamp(); bell(); kiosk(); phonebooth(); console()
    speaker(); control_panel(); bookshelf(); counter(); pew(); altar(); vending()
    # Compact object scale for the new 32px character height; keep hard edges.
    sizes = {
        'car.png':(56,40), 'car_rust.png':(56,40),
        'bus.png':(72,52), 'bus_rust.png':(72,52),
        'tree.png':(32,48), 'lamp.png':(16,40), 'kiosk.png':(40,36),
        'phonebooth.png':(28,40), 'console.png':(36,38), 'speaker.png':(24,28),
        'control_panel.png':(24,30), 'bookshelf.png':(32,38),
        'counter.png':(32,26), 'pew.png':(32,24), 'altar.png':(36,30),
        'vending.png':(28,34)
    }
    for name,size in sizes.items():
        im=Image.open(OUT/name).convert('RGBA').resize(size,Image.Resampling.NEAREST)
        im.save(OUT/name,format='PNG',optimize=True,compress_level=9)
    print('generated compact, shadow-free world-object PNGs')
