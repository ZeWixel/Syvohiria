#!/usr/bin/env python3
"""Generate small, individually editable pixel icons and title skyline art."""
from pathlib import Path
from PIL import Image, ImageDraw

OUT = Path(__file__).resolve().parents[1] / 'res' / 'art'
ICON_DIR = OUT / 'icons'
ICON_DIR.mkdir(parents=True, exist_ok=True)
INK = (21, 23, 24, 255)

def icon(draw_fn):
    im = Image.new('RGBA', (16, 16), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    draw_fn(d)
    return im.resize((12, 12), Image.Resampling.NEAREST)

def pipe(d):
    d.line((2,12,11,3), fill=INK, width=5)
    d.line((2,11,10,3), fill=(115,63,42,255), width=3)
    d.line((3,11,10,4), fill=(190,119,68,255), width=1)
    d.rectangle((1,10,4,13), fill=(48,43,38,255), outline=INK)
    d.point((8,5), fill=(224,176,111,255))

def pistol(d):
    d.polygon([(2,4),(12,4),(14,6),(8,7),(7,9),(5,9),(4,14),(2,14),(3,8),(2,7)], fill=(77,83,82,255), outline=INK)
    d.rectangle((4,2,12,4), fill=(154,158,146,255), outline=INK)
    d.rectangle((12,3,14,4), fill=(34,38,39,255))
    d.point((5,5), fill=(202,151,76,255))

def ammo(d):
    for x,y in ((2,8),(6,5),(10,8)):
        d.rectangle((x,y+2,x+2,y+7), fill=(187,137,59,255), outline=INK)
        d.polygon([(x,y+2),(x+1,y),(x+2,y+2)], fill=(218,188,117,255), outline=INK)
        d.line((x+1,y+4,x+1,y+6), fill=(237,212,144,255))

def flashlight(d):
    d.polygon([(3,12),(5,14),(12,6),(10,4)], fill=(79,86,82,255), outline=INK)
    d.line((5,11,10,6), fill=(157,162,148,255), width=2)
    d.polygon([(10,4),(14,2),(13,7),(11,7)], fill=(234,204,123,255), outline=INK)
    d.point((6,12), fill=(160,66,48,255))

def radio(d):
    d.line((5,4,3,1), fill=(174,177,165,255), width=1)
    d.rectangle((3,3,12,14), fill=(57,68,68,255), outline=INK)
    d.rectangle((5,5,10,8), fill=(30,42,45,255), outline=(128,136,122,255))
    d.line((6,6,9,6), fill=(170,191,166,255))
    d.ellipse((5,10,7,12), fill=(157,132,74,255), outline=INK)
    d.ellipse((9,10,11,12), fill=(127,53,44,255), outline=INK)
    d.point((11,4), fill=(214,56,42,255))

def medkit(d):
    d.rectangle((2,4,13,13), fill=(203,196,171,255), outline=INK)
    d.rectangle((4,3,11,5), fill=(149,143,124,255), outline=INK)
    d.rectangle((6,6,9,11), fill=(154,47,44,255))
    d.rectangle((5,7,10,10), fill=(154,47,44,255))
    d.point((4,12), fill=(239,221,190,255))

def thermos(d):
    d.rectangle((5,4,11,14), fill=(100,107,78,255), outline=INK)
    d.rectangle((6,2,10,4), fill=(57,61,49,255), outline=INK)
    d.rectangle((6,6,10,10), fill=(149,54,41,255))
    d.line((7,5,8,3), fill=(201,179,127,255))
    d.line((6,12,10,12), fill=(164,150,107,255))

def key(d, silver=False):
    metal=(183,150,89,255) if not silver else (157,165,163,255)
    d.ellipse((2,3,8,9), fill=metal, outline=INK)
    d.ellipse((4,5,6,7), fill=(30,31,31,255))
    d.line((7,8,13,14), fill=metal, width=2)
    d.line((10,11,12,9), fill=metal, width=2)
    d.line((12,13,14,11), fill=metal, width=2)
    d.point((3,4), fill=(235,206,131,255) if not silver else (223,226,218,255))

def boltcutters(d):
    d.line((4,8,2,14), fill=(135,48,39,255), width=2)
    d.line((7,8,10,14), fill=(135,48,39,255), width=2)
    d.line((4,8,7,5), fill=(170,177,168,255), width=2)
    d.line((7,5,12,3), fill=(97,105,101,255), width=2)
    d.line((7,5,13,8), fill=(97,105,101,255), width=2)
    d.ellipse((5,6,8,9), fill=(190,145,71,255), outline=INK)

def fuse(d):
    d.rectangle((3,6,12,10), fill=(118,150,143,255), outline=INK)
    d.rectangle((5,7,10,9), fill=(220,196,118,255))
    d.rectangle((1,6,3,10), fill=(166,151,110,255), outline=INK)
    d.rectangle((12,6,14,10), fill=(166,151,110,255), outline=INK)
    d.line((5,7,10,7), fill=(229,226,188,255))

def letter(d):
    d.polygon([(2,3),(11,2),(14,5),(13,13),(3,14)], fill=(211,198,161,255), outline=INK)
    d.line((3,5,8,9,13,4), fill=(118,74,54,255), width=1)
    d.line((3,13,6,9), fill=(118,74,54,255))
    d.line((10,9,13,13), fill=(118,74,54,255))
    d.point((10,4), fill=(164,46,41,255))

def pages(d):
    d.polygon([(2,4),(8,5),(8,14),(2,12)], fill=(218,210,181,255), outline=INK)
    d.polygon([(8,5),(14,3),(14,12),(8,14)], fill=(193,185,158,255), outline=INK)
    d.line((4,7,7,8), fill=(111,90,70,255))
    d.line((4,9,7,10), fill=(111,90,70,255))
    d.line((9,8,12,6), fill=(107,91,75,255))
    d.line((9,10,12,8), fill=(107,91,75,255))
    d.line((8,5,8,14), fill=INK)

funcs=[pipe,pistol,ammo,flashlight,radio,medkit,thermos,lambda d:key(d,False),lambda d:key(d,True),boltcutters,fuse,letter,pages]
for i, fn in enumerate(funcs):
    icon(fn).save(ICON_DIR / ('item%d.png'%i), optimize=True, compress_level=9)

# Static title skyline, transparent so the game can animate fog/reflections behind it.
im=Image.new('RGBA',(176,76),(0,0,0,0));d=ImageDraw.Draw(im)
ink=(13,14,16,255); edge=(31,32,35,255)
# Left village roof and wall.
d.polygon([(0,48),(17,34),(36,48),(36,75),(0,75)], fill=ink)
d.rectangle((4,50,32,75), fill=ink)
d.rectangle((11,56,14,63), fill=edge);d.rectangle((23,55,27,62), fill=edge)
# The church and its narrow, broken belfry form the central silhouette.
d.rectangle((65,39,111,75), fill=ink)
d.polygon([(63,40),(88,24),(113,40)], fill=ink)
d.rectangle((78,23,98,40), fill=ink)
d.polygon([(77,24),(88,9),(99,24)], fill=ink)
d.rectangle((85,6,91,10), fill=ink)
d.polygon([(83,6),(88,0),(93,6)], fill=ink)
d.rectangle((87,40,89,48), fill=edge)
d.rectangle((86,50,90,65), fill=edge)
d.rectangle((71,49,75,58), fill=edge);d.rectangle((101,49,105,58), fill=edge)
# Right-side station roof, radio mast, and low houses.
d.rectangle((128,49,175,75), fill=ink)
d.polygon([(126,49),(150,34),(174,49)], fill=ink)
d.rectangle((137,55,142,63), fill=edge);d.rectangle((156,55,162,63), fill=edge)
d.rectangle((145,22,147,36), fill=ink)
d.line((146,24,140,30), fill=edge,width=1);d.line((146,24,153,30), fill=edge,width=1)
d.line((146,25,146,32), fill=edge,width=1)
# Smaller rooftop silhouettes merge the skyline into the edges.
d.rectangle((35,56,63,75), fill=ink)
d.polygon([(33,56),(48,46),(65,56)], fill=ink)
d.rectangle((111,58,128,75), fill=ink)
d.polygon([(110,58),(119,51),(130,58)], fill=ink)
im.save(OUT / 'title_city.png', optimize=True, compress_level=9)
print('generated 13 editable item icons and title skyline PNG')
