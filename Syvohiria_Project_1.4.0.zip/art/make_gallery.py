#!/usr/bin/env python3
"""Build a compact visual QA sheet from the editable PNG art resources."""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

ROOT=Path(__file__).resolve().parents[1]
ART=ROOT/'res'/'art'
OUT=ROOT/'screenshots'/'gallery.png'
OUT.parent.mkdir(parents=True,exist_ok=True)
W,H=1100,930
im=Image.new('RGB',(W,H),(22,24,25)); d=ImageDraw.Draw(im)
font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',18)
small=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',12)
tiny=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',10)
d.text((20,14),'SYVOHIRIA · PIXEL ART / EDITABLE RESOURCE REVIEW',font=font,fill='#ded5c2')
d.text((20,40),'32px cast · user character/Nina sources · compact props · no painted drop shadows',font=small,fill='#9fa09a')

def panel(x,y,w,h,title):
    d.rounded_rectangle((x,y,x+w,y+h),radius=8,fill='#202324',outline='#565955',width=1)
    d.text((x+10,y+6),title,font=small,fill='#d5cdbb')

def paste(name,x,y,scale=1):
    a=Image.open(ART/name).convert('RGBA')
    a=a.resize((a.width*scale,a.height*scale),Image.Resampling.NEAREST)
    im.paste(a,(x,y),a)
    return a.size

# User-based protagonist and authored idle frames.
panel(20,68,500,143,'LUCA · WALK CYCLE · 32×32')
for i in range(4): paste(f'hero_d{i}.png',38+i*112,94,3)
panel(535,68,545,143,'IDLE + NINA · ORIGINAL USER PNGS NORMALIZED TO 32PX')
for i in range(3): paste(f'idle_d{i}.png',555+i*105,94,3)
paste('nina.png',890,94,3)
d.text((907,184),'Nina',font=tiny,fill='#b8b4a7')

panel(20,224,520,150,'FIST · FOUR FULL-BODY FRAMES · NO PROJECTILE')
for i in range(4): paste(f'punch_d{i}.png',40+i*119,252,3)
panel(555,224,525,150,'PIPE · FOUR FULL-BODY SWING FRAMES')
for i in range(4): paste(f'pipe_swing_d{i}.png',574+i*119,252,3)

panel(20,387,460,146,'PISTOL · HOLD + MUZZLE FLASH')
for i,name in enumerate(('pistol_d.png','pistol_d_fire2.png','pistol_s.png','pistol_u.png')):
    paste(name,35+i*108,413,3)
panel(495,387,585,146,'ENEMIES · COMPACT CANVASES / HYBRID BOSS')
for i,name in enumerate(('hollow0.png','hound0.png','flyer0.png','boss0.png')):
    a=Image.open(ART/name).convert('RGBA')
    scale=min(3,118/a.width,111/a.height)
    a=a.resize((int(a.width*scale),int(a.height*scale)),Image.Resampling.NEAREST)
    im.paste(a,(510+i*137+(118-a.width)//2,409+(111-a.height)//2),a)

panel(20,546,530,166,'WORLD PROPS · PNG ASSETS · NO GROUND SHADOWS')
for i,name in enumerate(('car.png','bus.png','tree.png','lamp.png','bell.png','kiosk.png')):
    a=Image.open(ART/name).convert('RGBA')
    scale=min(1.45,92/a.width,116/a.height)
    a=a.resize((int(a.width*scale),int(a.height*scale)),Image.Resampling.NEAREST)
    x=29+i*85+(76-a.width)//2; y=574+(116-a.height)//2
    im.paste(a,(x,y),a)
    d.text((30+i*85,690),name[:-4],font=tiny,fill='#b8b5aa')
panel(565,546,515,166,'EDITABLE INVENTORY ICON FILES')
for i in range(13):
    x=579+(i%7)*70; y=578+(i//7)*55
    paste(f'icons/item{i}.png',x,y,2)
    d.text((x+29,y+7),str(i),font=tiny,fill='#aaa69a')

panel(20,725,515,185,'ISOMETRIC TILES · THEME 0 · 32×16 FLOOR / WALL BLOCKS')
for i,name in enumerate(('floor0.png','floor1.png','floor2.png','pit.png','wall.png','door.png')):
    x=38+(i%3)*158; y=758+(i//3)*68
    paste(f'tiles/theme0/{name}',x,y,1)
    d.text((x+42,y+4),name[:-4],font=tiny,fill='#b8b5aa')
panel(550,725,530,185,'TITLE SKYLINE · TRANSPARENT PNG, SEPARATE FROM CODE')
paste('title_city.png',575,754,2)

im.save(OUT)
print('gallery:',OUT,im.size)
