#!/usr/bin/env python3
"""Compose editable 32x32 weapon and combat poses over the supplied player art."""
from pathlib import Path
from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'res' / 'art'
OUT.mkdir(parents=True, exist_ok=True)
INK=(20,16,19,255)
JACKET=(36,82,59,255)
JACKET_HI=(50,132,100,255)
JACKET_SHADE=(35,103,78,255)
SKIN=(250,214,184,255)
SKIN_HI=(254,243,192,255)
SKIN_SHADE=(186,117,106,255)
STEEL=(96,103,103,255)
STEEL_HI=(177,179,162,255)
RUST=(150,58,45,255)


def base(direction):
    return Image.open(OUT/f'idle_{direction}0.png').convert('RGBA')


def cut_right_hand(im):
    # Keep the supplied torso and sleeve; remove only the hand pixels that are
    # replaced by the pose overlay. The left hand and face remain untouched.
    skin={(250,214,184,255),(254,243,192,255),(186,117,106,255),(245,160,151,255)}
    px=im.load()
    for y in range(12,22):
        for x in range(21,29):
            if px[x,y] in skin: px[x,y]=(0,0,0,0)
    return im


def stroke(d, pts, color, width):
    d.line([(int(x),int(y)) for x,y in pts], fill=color, width=width)
    for x,y in pts:
        r=width//2
        d.ellipse((x-r,y-r,x+r,y+r),fill=color)


def hand(d, x, y, closed=True):
    x=int(x); y=int(y)
    if closed:
        d.polygon([(x-2,y-2),(x+1,y-3),(x+3,y-1),(x+3,y+1),
                   (x+1,y+3),(x-2,y+2),(x-3,y)], fill=SKIN, outline=INK)
        d.line((x-1,y-1,x+1,y-2), fill=SKIN_HI, width=1)
        d.point((x-1,y+1), fill=SKIN_SHADE)
    else:
        d.polygon([(x-2,y-2),(x+1,y-3),(x+3,y),(x+2,y+3),
                   (x-2,y+3),(x-3,y)], fill=SKIN, outline=INK)
        d.line((x-1,y-1,x+1,y-2), fill=SKIN_HI, width=1)


def arm(d, shoulder, elbow, wrist, with_hand=True):
    pts=[shoulder,elbow,wrist]
    stroke(d,pts,INK,5)
    stroke(d,pts,JACKET,3)
    stroke(d,[shoulder,elbow],JACKET_HI,1)
    # A dark cuff and a narrow olive seam keep the tiny arm readable.
    x,y=wrist
    d.line((x-2,y-1,x+1,y+1), fill=INK, width=4)
    d.point((x-1,y-1), fill=JACKET_HI)
    if with_hand: hand(d,x,y+2,True)


def pipe(d, grip, tip):
    gx,gy=grip; tx,ty=tip
    pts=[(gx,gy),(tx,ty)]
    stroke(d,pts,INK,5)
    stroke(d,pts,STEEL,3)
    d.line((gx-1,gy-1,tx-1,ty-1),fill=STEEL_HI,width=1)
    # Rust rings are placed on the shaft, not as a ground shadow.
    for f in (0.30,0.68):
        x=int(gx+(tx-gx)*f); y=int(gy+(ty-gy)*f)
        d.point((x,y),fill=RUST)
        d.point((x+1,y),fill=(191,88,57,255))
    d.point((tx,ty),fill=(38,42,42,255))


def pistol(d, wrist, direction, flash=False):
    x,y=wrist
    if direction=='d':
        # Down-facing: compact service pistol aimed to the right of the fist.
        d.polygon([(x-2,y-3),(x+3,y-3),(x+7,y-2),(x+8,y),
                   (x+5,y+2),(x+2,y+2),(x+1,y+6),(x-1,y+5),
                   (x,y+1),(x-2,y)], fill=(43,48,49,255), outline=INK)
        d.line((x-1,y-2,x+4,y-2),fill=STEEL_HI,width=1)
        d.line((x+2,y-1,x+6,y-1),fill=STEEL,width=1)
        d.line((x+1,y+2,x,y+5),fill=(67,68,64,255),width=2)
        d.line((x+2,y+2,x+4,y+4,x+2,y+4),fill=INK,width=1)
        muzzle=(x+8,y-1)
    elif direction=='u':
        # Up-facing: the muzzle angles up; the dark grip remains under the fist.
        d.polygon([(x-1,y+1),(x+1,y-2),(x+4,y-5),(x+6,y-5),
                   (x+7,y-3),(x+4,y),(x+3,y+3),(x+1,y+6)],
                  fill=(43,48,49,255),outline=INK)
        d.line((x+1,y-1,x+4,y-4),fill=STEEL_HI,width=1)
        d.line((x+2,y+1,x+5,y-2),fill=STEEL,width=1)
        d.line((x+2,y+2,x,y+6),fill=(67,68,64,255),width=2)
        muzzle=(x+7,y-4)
    else:
        # Side-facing: low horizontal aim, clearly separated slide and grip.
        d.polygon([(x-2,y-2),(x+3,y-3),(x+7,y-2),(x+8,y),
                   (x+6,y+1),(x+3,y+1),(x+1,y+5),(x-1,y+4),
                   (x,y),(x-2,y)], fill=(43,48,49,255),outline=INK)
        d.line((x-1,y-2,x+4,y-3),fill=STEEL_HI,width=1)
        d.line((x+2,y-1,x+6,y-2),fill=STEEL,width=1)
        d.line((x+1,y+1,x,y+5),fill=(67,68,64,255),width=2)
        d.line((x+3,y+1,x+4,y+3,x+2,y+3),fill=INK,width=1)
        muzzle=(x+8,y-1)
    if flash:
        fx,fy=muzzle
        d.polygon([(fx,fy),(fx+2,fy-2),(fx+1,fy),(fx+3,fy+1),
                   (fx,fy+2),(fx-1,fy+1)],fill=(244,190,87,255))
        d.point((fx+1,fy),fill=(255,244,175,255))


def pose(direction, elbow, wrist, kind, tip=None, flash=False):
    im=cut_right_hand(base(direction))
    d=ImageDraw.Draw(im)
    shoulder={'d':(21,12),'u':(21,12),'s':(22,12)}[direction]
    # Draw the metal weapon behind the fingers so the hand visibly grips it.
    if kind=='pipe' and tip is not None:
        pipe(d,(wrist[0],wrist[1]+1),tip)
    arm(d,shoulder,elbow,wrist,with_hand=(kind!='gun'))
    if kind=='gun':
        pistol(d,(wrist[0],wrist[1]+1),direction,flash)
        # Two short skin pixels wrap the grip, making the hand connection clear.
        d.line((wrist[0]-1,wrist[1]+2,wrist[0]+1,wrist[1]+3),fill=SKIN_HI,width=2)
    return im


# Idle weapon holds use the user's static standing drawings as the base.
HOLD={
 'd':((23,14),(23,17),(18,3)),
 'u':((23,14),(23,17),(18,3)),
 's':((23,14),(23,17),(18,4)),
}
for direction in ('d','u','s'):
    elbow,wrist,tip=HOLD[direction]
    pose(direction,elbow,wrist,'pipe',tip).save(OUT/f'pipe_hold_{direction}.png',optimize=True)
    pose(direction,elbow,wrist,'gun').save(OUT/f'pistol_{direction}.png',optimize=True)

# Four full-body punch poses; no projectile is drawn in any frame.
PUNCH={
 'd':[((22,15),(22,17)),((24,15),(25,17)),((25,17),(29,20)),((23,16),(24,19))],
 'u':[((22,15),(22,17)),((24,12),(25,10)),((24,9),(27,5)),((23,12),(24,10))],
 's':[((23,15),(24,17)),((25,14),(27,15)),((27,13),(28,14)),((25,16),(27,18))],
}
for direction in ('d','u','s'):
    for i,(elbow,wrist) in enumerate(PUNCH[direction]):
        pose(direction,elbow,wrist,'fist').save(OUT/f'punch_{direction}{i}.png',optimize=True)

# Pipe swings: the shaft travels through four distinct arcs, with the same grip
# visible throughout. The direction-specific arc mirrors cleanly for left movement.
SWINGS={
 'd':[((22,15),(22,17),(15,5)),((24,13),(25,14),(30,4)),
      ((25,16),(28,18),(31,20)),((23,18),(24,20),(14,29))],
 'u':[((22,14),(22,16),(14,28)),((24,13),(25,12),(30,28)),
      ((25,11),(27,9),(30,3)),((23,14),(24,16),(15,4))],
 's':[((23,14),(24,16),(13,28)),((25,13),(26,14),(30,4)),
      ((26,12),(28,12),(31,10)),((24,16),(25,18),(14,30))],
}
for direction in ('d','u','s'):
    for i,(elbow,wrist,tip) in enumerate(SWINGS[direction]):
        pose(direction,elbow,wrist,'pipe',tip).save(OUT/f'pipe_swing_{direction}{i}.png',optimize=True)

# Pistol firing poses are full 32x32 composites, not a separate flash projectile.
for direction in ('d','u','s'):
    elbow,wrist,_=HOLD[direction]
    pose(direction,elbow,wrist,'gun',flash=False).save(OUT/f'pistol_{direction}_fire1.png',optimize=True)
    pose(direction,elbow,wrist,'gun',flash=True).save(OUT/f'pistol_{direction}_fire2.png',optimize=True)

# Remove superseded overlay-only art so the packed art tree is unambiguous.
for f in OUT.glob('arm_idle_*.png'):
    f.unlink()
print('generated full 32x32 hand/weapon/action sprites')
