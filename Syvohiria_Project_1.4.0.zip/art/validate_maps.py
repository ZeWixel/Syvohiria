#!/usr/bin/env python3
"""Validate editable level INI grids, object coordinates, and enemy spawns."""
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
MAPS=ROOT/'res'/'maps'
FILES=('street.ini','post.ini','church.ini','radio.ini')
errors=[]

def parse(path):
    sections={}; sec=''
    for raw in path.read_text(encoding='utf-8').splitlines():
        line=raw.strip()
        if not line or line.startswith(';'): continue
        if line.startswith('[') and line.endswith(']'):
            sec=line[1:-1].lower(); sections.setdefault(sec,[]); continue
        if sec: sections.setdefault(sec,[]).append(line)
    return sections

parsed={}
for filename in FILES:
    p=MAPS/filename
    if not p.exists():
        errors.append(f'{filename}: missing')
        continue
    sections=parse(p); parsed[filename]=sections; dims={}
    for section in ('normal','rust'):
        rows=[s for s in sections.get(section,[]) if '=' not in s]
        if not rows: continue
        widths=set(map(len,rows))
        if len(widths)!=1: errors.append(f'{filename} [{section}]: non-uniform row widths {sorted(widths)}')
        if any(not row.isascii() for row in rows): errors.append(f'{filename} [{section}]: non-ASCII tile')
        dims[section]=(len(rows[0]),len(rows))
    if not dims:
        errors.append(f'{filename}: missing [normal] grid'); continue
    w,h=dims.get('normal',next(iter(dims.values())))
    for pair in sections.get('objects',[]):
        if '=' not in pair or not pair.startswith('obj'): continue
        key,value=pair.split('=',1)
        try: x,y=map(int,value.split(','))
        except Exception:
            errors.append(f'{filename}: malformed {pair}'); continue
        if not (0<=x<w and 0<=y<h): errors.append(f'{filename}: {key} outside grid: {x},{y}')
    for pair in sections.get('enemies',[]):
        if '=' not in pair or not pair.startswith('enemy'): continue
        key,value=pair.split('=',1); parts=value.split(',')
        if len(parts)!=4 or parts[0] not in ('hollow','hound','flyer','boss') or parts[3] not in ('interior','base','normal','rust'):
            errors.append(f'{filename}: malformed {pair}'); continue
        try: x,y=int(parts[1]),int(parts[2])
        except Exception:
            errors.append(f'{filename}: malformed coordinates in {pair}'); continue
        if not (0<=x<w and 0<=y<h): errors.append(f'{filename}: {key} outside grid: {x},{y}')
    print(f'{filename}: {len(sections.get("normal",[]))} normal rows; '
          f'{len(sections.get("rust",[]))} rust rows; '
          f'{len(sections.get("objects",[]))} object coordinates; '
          f'{len(sections.get("enemies",[]))} enemy spawns')

church=parsed.get('church.ini',{})
rows=[x for x in church.get('normal',[]) if '=' not in x]
if len(rows)>4 and len(rows[4])>5:
    row=rows[4]
    if row[5]!='D' or row[4] not in ',.': errors.append('church.ini: tower door/passable tile regression at row 4')
    objects=dict(item.split('=',1) for item in church.get('objects',[]) if '=' in item)
    if objects.get('obj1')!='5,4' or objects.get('obj5')!='3,4':
        errors.append('church.ini: bell/tower interaction positions unexpected')
else: errors.append('church.ini: missing tower row')

if errors:
    print('ERRORS:')
    for error in errors: print(' -',error)
    raise SystemExit(1)
print('INI maps are structurally valid; church tower entry remains walkable beside door.')
