#!/bin/sh
# Збірка J2ME MIDlet: ECJ (-target cldc1.1 = preverified StackMap) + MIDP2/CLDC1.1 API
set -e
T=$HOME/tools
cd "$(dirname "$0")"
rm -rf classes dist && mkdir -p classes dist
java -jar $T/ecj-4.6.1.jar -encoding UTF-8 -source 1.3 -target cldc1.1 -nowarn \
  -bootclasspath $T/cldcapi11-2.0.4.jar:$T/midpapi20-2.0.4.jar -d classes src/*.java
cp res/icon.png classes/ 2>/dev/null || true
mkdir -p classes/art classes/maps
cp -R res/art/. classes/art/
cp -R res/maps/. classes/maps/
cat > dist/MANIFEST.MF <<M
Manifest-Version: 1.0
MIDlet-1: Syvohiria, /icon.png, Main
MIDlet-Name: Syvohiria
MIDlet-Vendor: Arena Demake
MIDlet-Version: 1.4.0
MIDlet-Icon: /icon.png
MicroEdition-Profile: MIDP-2.0
MicroEdition-Configuration: CLDC-1.1
M
python3 - <<P
import zipfile,os
z=zipfile.ZipFile('dist/Syvohiria.jar','w',zipfile.ZIP_DEFLATED)
z.writestr('META-INF/MANIFEST.MF',open('dist/MANIFEST.MF').read().replace('\\n','\\r\\n'))
for root,dirs,files in os.walk('classes'):
 for f in sorted(files):
  p=os.path.join(root,f); z.write(p,os.path.relpath(p,'classes'))
z.close()
P
SIZE=$(stat -c %s dist/Syvohiria.jar)
cat > dist/Syvohiria.jad <<J
MIDlet-1: Syvohiria, /icon.png, Main
MIDlet-Name: Syvohiria
MIDlet-Vendor: Arena Demake
MIDlet-Version: 1.4.0
MIDlet-Icon: /icon.png
MIDlet-Jar-URL: Syvohiria.jar
MIDlet-Jar-Size: $SIZE
MicroEdition-Profile: MIDP-2.0
MicroEdition-Configuration: CLDC-1.1
J
rm dist/MANIFEST.MF
echo "JAR: $SIZE bytes"
